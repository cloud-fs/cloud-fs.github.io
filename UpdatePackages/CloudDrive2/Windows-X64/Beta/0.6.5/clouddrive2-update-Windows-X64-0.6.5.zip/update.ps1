$exec= $args[0]
$destdir=$args[1]
$srcdir=$args[2]
Remove-Item -Path "$destdir\clouddrive.exe.tmp" -Force
Rename-Item -Path $exec -NewName "clouddrive.exe.tmp" -Force
Copy-Item -Path "$srcdir\*" -Destination "$destdir" -Recurse -force
Stop-Service -Name "CloudDrive2"
Stop-Process -Name "clouddrive" -Force
Start-Sleep -Seconds 2
Start-Service -Name "CloudDrive2"