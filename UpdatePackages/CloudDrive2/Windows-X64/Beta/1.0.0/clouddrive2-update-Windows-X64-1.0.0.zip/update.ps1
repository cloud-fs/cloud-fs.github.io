$exec= $args[0]
$destdir=$args[1]
$srcdir=$args[2]
Remove-Item -Path "$destdir\clouddrive.exe.tmp" -Force
Rename-Item -Path $exec -NewName "clouddrive.exe.tmp" -Force
Copy-Item -Path "$srcdir\*" -Destination "$destdir" -Recurse -force
#sleep 2 seconds
#Start-Sleep -s 2
Restart-Service -Name "CloudDrive2"
