// CloudDrive web console: the book reader (EPUB, MOBI, AZW, AZW3, CBZ).
//
// src/components/book_reader.rs loads this module with a dynamic import and draws the
// bars, panels and messages around it. The book itself is rendered by foliate-js
// (./foliate, MIT, pinned; see ./foliate/README.md). This module adds what foliate-js
// leaves to the app:
//
// - bytes: HTTP Range reads of the signed /static URL through a 256 KB block cache
//   (files up to 8 MB are fetched whole);
// - refusing protected (DRM) books and Kindle KFX before anything is rendered: foliate-js
//   checks neither;
// - removing book scripts before a section reaches its frame (foliate's frames allow
//   scripts and share this page's origin), plus a Content-Security-Policy in each section;
// - its own SHA-1 for EPUB font obfuscation: crypto.subtle needs a secure context, and a
//   console on plain HTTP isn't one;
// - reading positions in localStorage under `clouddrive.bookPositions`, keyed by the
//   file's full path. They stay in this browser and don't sync with the apps.

import './foliate/view.js'

const POSITIONS_KEY = 'clouddrive.bookPositions'
const SETTINGS_KEY = 'clouddrive.bookReaderSettings'
const BLOCK_SIZE = 256 * 1024
const WHOLE_FILE_LIMIT = 8 * 1024 * 1024
const MAX_CACHED_BLOCKS = 192 // 48 MB
const MAX_READ_AHEAD = 8 // blocks, on sequential reads
const MAX_POSITIONS = 500
const REQUEST_TIMEOUT_MS = 30000

// Error codes the Rust side turns into messages.
const PROTECTED = 'PROTECTED'
const KFX = 'KFX'
const DAMAGED = 'DAMAGED'
const NETWORK = 'NETWORK'

class ReaderError extends Error {
    constructor(code, message, options) {
        super(message ?? code, options)
        this.name = 'ReaderError'
        this.code = code
    }
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

// Two animation frames, or 100 ms where frames don't run (a background tab).
const nextFrames = () => new Promise(resolve => {
    const timer = setTimeout(resolve, 100)
    requestAnimationFrame(() => requestAnimationFrame(() => {
        clearTimeout(timer)
        resolve()
    }))
})

// ---------------------------------------------------------------------------
// SHA-1 (FIPS 180-4), for the IDPF font obfuscation key. Returns 20 bytes.
// ---------------------------------------------------------------------------

export const sha1Bytes = bytes => {
    const length = bytes.length
    const padded = (((length + 8) >> 6) + 1) << 6
    const buf = new Uint8Array(padded)
    buf.set(bytes)
    buf[length] = 0x80
    const dv = new DataView(buf.buffer)
    dv.setUint32(padded - 8, Math.floor(length / 0x20000000))
    dv.setUint32(padded - 4, (length << 3) >>> 0)
    let h0 = 0x67452301, h1 = 0xefcdab89, h2 = 0x98badcfe, h3 = 0x10325476, h4 = 0xc3d2e1f0
    const w = new Uint32Array(80)
    for (let offset = 0; offset < padded; offset += 64) {
        for (let i = 0; i < 16; i++) w[i] = dv.getUint32(offset + i * 4)
        for (let i = 16; i < 80; i++) {
            const x = w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]
            w[i] = (x << 1) | (x >>> 31)
        }
        let a = h0, b = h1, c = h2, d = h3, e = h4
        for (let i = 0; i < 80; i++) {
            let f, k
            if (i < 20) { f = (b & c) | (~b & d); k = 0x5a827999 }
            else if (i < 40) { f = b ^ c ^ d; k = 0x6ed9eba1 }
            else if (i < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8f1bbcdc }
            else { f = b ^ c ^ d; k = 0xca62c1d6 }
            const t = (((a << 5) | (a >>> 27)) + f + e + k + w[i]) >>> 0
            e = d
            d = c
            c = ((b << 30) | (b >>> 2)) >>> 0
            b = a
            a = t
        }
        h0 = (h0 + a) >>> 0
        h1 = (h1 + b) >>> 0
        h2 = (h2 + c) >>> 0
        h3 = (h3 + d) >>> 0
        h4 = (h4 + e) >>> 0
    }
    const out = new Uint8Array(20)
    const ov = new DataView(out.buffer)
    ;[h0, h1, h2, h3, h4].forEach((h, i) => ov.setUint32(i * 4, h))
    return out
}

// epub.js calls this with the book's unique identifier and expects the digest.
const sha1 = async str => sha1Bytes(new TextEncoder().encode(str))

// ---------------------------------------------------------------------------
// Bytes: a Blob-like file read by HTTP Range, with a block cache.
// foliate-js and zip.js only use `size`, `name`, `type`, `slice()` and
// `arrayBuffer()`, which is all this provides.
// ---------------------------------------------------------------------------

const clampIndex = (value, size, fallback) => {
    if (value === undefined || value === null) return fallback
    value = Math.trunc(Number(value))
    if (Number.isNaN(value)) return fallback
    return value < 0 ? Math.max(size + value, 0) : Math.min(value, size)
}

const parseContentRange = value => {
    const match = /\/\s*(\d+)\s*$/.exec(value ?? '')
    return match ? Number(match[1]) : null
}

// fetch() with a timeout, cancelled with the session.
const fetchWithTimeout = async (url, init, signal) => {
    const controller = new AbortController()
    const onAbort = () => controller.abort()
    signal?.addEventListener('abort', onAbort, { once: true })
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS)
    try {
        return await fetch(url, { ...init, signal: controller.signal })
    } finally {
        clearTimeout(timer)
        signal?.removeEventListener('abort', onAbort)
    }
}

const httpError = res => new ReaderError(
    res.status === 416 ? DAMAGED : NETWORK, `HTTP ${res.status}`)

// GET `url` (a byte range when `range` is set), retrying network failures twice.
const fetchBytes = async (url, range, signal) => {
    let lastError
    for (let attempt = 0; attempt < 3; attempt++) {
        if (attempt) await sleep(500 * attempt)
        if (signal?.aborted) throw new ReaderError(NETWORK, 'Cancelled')
        let res
        try {
            res = await fetchWithTimeout(url,
                range ? { headers: { Range: `bytes=${range[0]}-${range[1] - 1}` } } : {}, signal)
        } catch (e) {
            lastError = e
            continue
        }
        if (res.status >= 500) {
            lastError = httpError(res)
            continue
        }
        if (!res.ok) throw httpError(res)
        try {
            return { res, bytes: new Uint8Array(await res.arrayBuffer()) }
        } catch (e) {
            lastError = e
        }
    }
    throw new ReaderError(NETWORK, 'The book could not be downloaded', { cause: lastError })
}

class RangeSlice {
    #file
    #start
    #end
    constructor(file, start, end) {
        this.#file = file
        this.#start = start
        this.#end = Math.max(start, end)
    }
    get size() {
        return this.#end - this.#start
    }
    get type() {
        return ''
    }
    slice(start, end) {
        const size = this.size
        const a = clampIndex(start, size, 0)
        const b = clampIndex(end, size, size)
        return new RangeSlice(this.#file, this.#start + a, this.#start + Math.max(a, b))
    }
    async arrayBuffer() {
        const bytes = await this.#file.read(this.#start, this.#end)
        return bytes.buffer
    }
    async text() {
        return new TextDecoder().decode(await this.#file.read(this.#start, this.#end))
    }
}

class RemoteFile {
    #url
    #size
    #blocks = new Map() // block index → Promise<Uint8Array>; insertion order is LRU order
    #signal
    #onNetworkError
    #lastEnd = -1
    #readAhead = 0
    constructor({ url, size, name, type, signal, onNetworkError, firstBlock }) {
        this.#url = url
        this.#size = size
        this.name = name
        this.type = type ?? ''
        this.#signal = signal
        this.#onNetworkError = onNetworkError
        if (firstBlock) this.#blocks.set(0, Promise.resolve(firstBlock))
    }
    get size() {
        return this.#size
    }
    slice(start, end) {
        const size = this.#size
        const a = clampIndex(start, size, 0)
        const b = clampIndex(end, size, size)
        return new RangeSlice(this, a, Math.max(a, b))
    }
    async arrayBuffer() {
        return (await this.read(0, this.#size)).buffer
    }
    // Bytes [start, end) as a new Uint8Array.
    async read(start, end) {
        end = Math.min(end, this.#size)
        if (end <= start) return new Uint8Array(0)
        const first = Math.floor(start / BLOCK_SIZE)
        const last = Math.floor((end - 1) / BLOCK_SIZE)
        // zip.js and mobi.js read an entry or a record front to back; read ahead
        // more and more blocks while that goes on, in one request each time.
        const sequential = start === this.#lastEnd
        this.#lastEnd = end
        this.#readAhead = sequential
            ? Math.min(MAX_READ_AHEAD, Math.max(1, this.#readAhead * 2)) : 0
        this.#request(first, last, this.#readAhead)
        const blocks = []
        for (let i = first; i <= last; i++) blocks.push(this.#blocks.get(i))
        const parts = await Promise.all(blocks)
        const out = new Uint8Array(end - start)
        let pos = 0
        parts.forEach((part, n) => {
            const blockStart = (first + n) * BLOCK_SIZE
            const from = Math.max(start - blockStart, 0)
            const to = Math.min(end - blockStart, part.length)
            if (to > from) {
                out.set(part.subarray(from, to), pos)
                pos += to - from
            }
        })
        if (pos !== out.length) throw new ReaderError(DAMAGED, 'Short read')
        return out
    }
    #touch(index) {
        const block = this.#blocks.get(index)
        this.#blocks.delete(index)
        this.#blocks.set(index, block)
    }
    #request(first, last, extra) {
        const lastBlock = Math.floor((this.#size - 1) / BLOCK_SIZE)
        let i = first
        while (i <= last) {
            if (this.#blocks.has(i)) {
                this.#touch(i)
                i++
                continue
            }
            let j = i
            while (j < last && !this.#blocks.has(j + 1)) j++
            if (j === last)
                for (let k = 0; k < extra && j < lastBlock && !this.#blocks.has(j + 1); k++) j++
            this.#fetchRun(i, j)
            i = j + 1
        }
        this.#evict(last - first + 1 + extra)
    }
    #fetchRun(a, b) {
        const start = a * BLOCK_SIZE
        const end = Math.min((b + 1) * BLOCK_SIZE, this.#size)
        const run = fetchBytes(this.#url, [start, end], this.#signal).then(({ res, bytes }) => {
            if (res.status === 206) {
                const total = parseContentRange(res.headers.get('Content-Range'))
                if (total !== null && total !== this.#size)
                    throw new ReaderError(DAMAGED, 'The file changed while it was being read')
                if (bytes.length !== end - start) throw new ReaderError(DAMAGED, 'Short read')
                return bytes
            }
            // The server ignored the Range header and sent the whole file.
            if (bytes.length !== this.#size) throw new ReaderError(DAMAGED, 'Unexpected size')
            return bytes.subarray(start, end)
        }).catch(e => {
            if (e?.code === NETWORK) this.#onNetworkError?.()
            throw e
        })
        for (let i = a; i <= b; i++) {
            const offset = (i - a) * BLOCK_SIZE
            const block = run.then(bytes => bytes.slice(offset, offset + BLOCK_SIZE))
            // A failed block is forgotten, so turning the page again retries it.
            block.catch(() => {
                if (this.#blocks.get(i) === block) this.#blocks.delete(i)
            })
            this.#blocks.set(i, block)
        }
    }
    #evict(keep) {
        const limit = Math.max(MAX_CACHED_BLOCKS, keep)
        for (const index of this.#blocks.keys()) {
            if (this.#blocks.size <= limit) break
            this.#blocks.delete(index)
        }
    }
}

// Open the book's bytes: the whole file when it's small, else a RemoteFile.
const openFile = async ({ url, name, size, signal, onNetworkError }) => {
    if (size > 0 && size <= WHOLE_FILE_LIMIT) {
        const { bytes } = await fetchBytes(url, null, signal)
        return new File([bytes], name)
    }
    // The first block: its Content-Range carries the size that counts.
    const { res, bytes } = await fetchBytes(url, [0, BLOCK_SIZE], signal)
    if (res.status !== 206) return new File([bytes], name) // no Range support: got it all
    const total = parseContentRange(res.headers.get('Content-Range')) ?? size
    if (!total) throw new ReaderError(DAMAGED, 'Unknown file size')
    if (bytes.length >= total) return new File([bytes.subarray(0, total)], name)
    return new RemoteFile({ url, size: total, name, signal, onNetworkError, firstBlock: bytes })
}

// ---------------------------------------------------------------------------
// Book scripts: removed before a section reaches its frame.
// ---------------------------------------------------------------------------

const XHTML_NS = 'http://www.w3.org/1999/xhtml'
const SECTION_CSP = "default-src 'none'; img-src blob: data:; media-src blob: data:; "
    + "font-src blob: data:; style-src blob: data: 'unsafe-inline'; form-action 'none'; "
    + "base-uri 'none'"
const REMOVED_ELEMENTS = new Set([
    'script', 'noscript', 'template', 'iframe', 'frame', 'frameset', 'object', 'embed',
    'applet', 'portal', 'base', 'handler', 'listener',
])
const URL_ATTRIBUTES = new Set([
    'href', 'src', 'action', 'formaction', 'data', 'poster', 'background', 'lowsrc',
    'dynsrc', 'codebase', 'cite', 'longdesc', 'usemap', 'ping', 'manifest',
])
// eslint-disable-next-line no-control-regex
const isScriptURL = value => {
    const v = String(value).replace(/[\u0000- \u007f-\u009f]+/g, '').toLowerCase()
    return /^(javascript|vbscript|livescript):/.test(v)
        || /^data:(text\/html|application\/xhtml\+xml|text\/xml|application\/xml)/.test(v)
}

// CSS may only point at the book itself. By the time markup or a stylesheet gets
// here, foliate has turned every file of the book into a blob: URL, so any other
// url(), @import or image-set() string reaches outside: it becomes `none` (a
// declaration where that isn't valid, such as a font's src, is then dropped), or the
// @import goes. Book images, a cover drawn as a body background included, keep working.
const isBookURL = url => /^\s*(blob:|data:|#)/i.test(url)
const NOWHERE = 'none'
const CSS_URL = /url\(\s*(?:"((?:[^"\\]|\\[\s\S])*)"|'((?:[^'\\]|\\[\s\S])*)'|([^)"'\s]*))\s*\)/gi
const CSS_IMPORT = /@import\s+(?:url\(\s*)?(["']?)([^"')\s;]*)\1\s*\)?[^;]*;?/gi
const CSS_STRING = /(["'])((?:(?!\1)[^\\]|\\[\s\S])*)\1/g

// image-set() also takes plain strings as URLs.
const cleanImageSets = css => {
    const opening = /(?:-webkit-)?image-set\(/gi
    let out = ''
    let from = 0
    for (let m = opening.exec(css); m; m = opening.exec(css)) {
        const start = m.index + m[0].length
        let end = start
        let depth = 1
        let quote = null
        for (; end < css.length && depth; end++) {
            const c = css[end]
            if (quote) {
                if (c === '\\') end++
                else if (c === quote) quote = null
            } else if (c === '"' || c === "'") quote = c
            else if (c === '(') depth++
            else if (c === ')') depth--
        }
        const inner = css.slice(start, depth ? end : end - 1)
        out += css.slice(from, start)
            + inner.replace(CSS_STRING, (string, _q, url) => isBookURL(url) ? string : NOWHERE)
            + (depth ? '' : ')')
        from = end
        opening.lastIndex = end
    }
    return out + css.slice(from)
}

export const cleanCSS = css => cleanImageSets(String(css ?? '')
    .replace(CSS_IMPORT, (rule, _q, url) => isBookURL(url) ? rule : '')
    .replace(CSS_URL, (whole, dq, sq, bare) => isBookURL(dq ?? sq ?? bare ?? '') ? whole : NOWHERE))

const HAS_CSS_URL = /url\(|@import|image-set\(/i

export const sanitizeDocument = (doc, addCSP) => {
    for (const node of [...doc.childNodes]) {
        if (node.nodeType !== 7 || node.target !== 'xml-stylesheet') continue
        // XSLT stylesheets can write scripts of their own; other sheets must be the book's.
        const href = /href\s*=\s*["']([^"']*)["']/i.exec(node.data)?.[1] ?? ''
        if (!/type\s*=\s*["']text\/css["']/i.test(node.data) || !isBookURL(href)) node.remove()
    }
    for (const el of doc.querySelectorAll('*')) {
        const name = el.localName.toLowerCase()
        if (REMOVED_ELEMENTS.has(name)) {
            el.remove()
            continue
        }
        if (name === 'meta') {
            const equiv = el.getAttribute('http-equiv')?.trim()?.toLowerCase()
            if (equiv === 'refresh' || equiv === 'set-cookie') {
                el.remove()
                continue
            }
        }
        if (name === 'link') {
            const rel = el.getAttribute('rel') ?? ''
            if (/\b(import|prefetch|preload|modulepreload|preconnect|dns-prefetch|prerender)\b/i.test(rel)
                || (/\bstylesheet\b/i.test(rel) && !isBookURL(el.getAttribute('href') ?? ''))) {
                el.remove()
                continue
            }
        }
        if (name === 'style' && HAS_CSS_URL.test(el.textContent)) el.textContent = cleanCSS(el.textContent)
        // SVG animation that writes a link (`<set attributeName="href" to="javascript:…">`).
        if ((name === 'set' || name.startsWith('animate'))
            && /href/i.test(el.getAttribute('attributeName') ?? '')) {
            el.remove()
            continue
        }
        for (const attr of [...el.attributes]) {
            const attrName = attr.localName.toLowerCase()
            if (attrName.startsWith('on') || attrName === 'srcdoc'
                || (URL_ATTRIBUTES.has(attrName) && isScriptURL(attr.value)))
                el.removeAttributeNode(attr)
            // `style`, and SVG presentation attributes such as fill="url(…)"
            else if (HAS_CSS_URL.test(attr.value)) attr.value = cleanCSS(attr.value)
        }
    }
    if (addCSP) addSectionCSP(doc)
    return doc
}

const addSectionCSP = doc => {
    const root = doc.documentElement
    if (!root || root.localName.toLowerCase() !== 'html') return
    let head = [...root.children].find(el => el.localName.toLowerCase() === 'head')
    if (!head) {
        head = doc.createElementNS(XHTML_NS, 'head')
        root.prepend(head)
    }
    const meta = doc.createElementNS(XHTML_NS, 'meta')
    meta.setAttribute('http-equiv', 'Content-Security-Policy')
    meta.setAttribute('content', SECTION_CSP)
    // after a charset declaration, which has to come early
    const charset = [...head.children].find(el => el.localName.toLowerCase() === 'meta'
        && (el.hasAttribute('charset')
            || el.getAttribute('http-equiv')?.toLowerCase() === 'content-type'))
    if (charset) charset.after(meta)
    else head.prepend(meta)
}

// The document type a media type stands for, or null when it isn't markup.
const markupType = type => {
    if (!type) return null
    if (type.includes('svg')) return 'image/svg+xml'
    if (type.includes('xhtml')) return 'application/xhtml+xml'
    if (type.includes('html')) return 'text/html'
    if (type === 'text/xml' || type === 'application/xml' || type.endsWith('+xml'))
        return 'application/xml'
    return null
}

// Types a frame can't run scripts from; anything else is served as plain text so the
// browser can't sniff it into HTML.
const isInertType = type =>
    /^(image\/(?!svg)|font\/|audio\/|video\/|text\/css$|text\/plain$|application\/octet-stream$)/.test(type)
    || /^application\/(x-)?(font|opentype|truetype)|^application\/vnd\.ms-(opentype|fontobject)$/.test(type)
    || /^(application|text)\/(x-)?(javascript|ecmascript)$/.test(type)

const toText = async data => {
    if (typeof data === 'string') return data
    if (data instanceof Blob) return data.text()
    if (data instanceof ArrayBuffer || ArrayBuffer.isView(data))
        return new TextDecoder().decode(data)
    return String(data ?? '')
}

// A book's own SVG page reaches its frame inside a small XHTML page, which carries the
// same Content-Security-Policy as every other section (an SVG document can't). Its size
// goes into a viewport meta, where foliate's fixed-layout renderer looks for it.
const svgPage = svgDoc => {
    const svg = svgDoc.documentElement
    const box = (svg.getAttribute('viewBox') ?? '').trim().split(/[\s,]+/).map(Number)
    const length = name => {
        const value = svg.getAttribute(name)?.trim() ?? ''
        return /^\d+(\.\d+)?(px)?$/.test(value) ? parseFloat(value) : NaN
    }
    const width = box.length === 4 && box[2] > 0 ? box[2] : length('width')
    const height = box.length === 4 && box[3] > 0 ? box[3] : length('height')
    const doc = document.implementation.createDocument(XHTML_NS, 'html', null)
    const head = doc.createElementNS(XHTML_NS, 'head')
    const meta = attributes => {
        const el = doc.createElementNS(XHTML_NS, 'meta')
        for (const [name, value] of Object.entries(attributes)) el.setAttribute(name, value)
        head.append(el)
    }
    meta({ 'http-equiv': 'Content-Security-Policy', content: SECTION_CSP })
    if (width > 0 && height > 0) meta({ name: 'viewport', content: `width=${width}, height=${height}` })
    const style = doc.createElementNS(XHTML_NS, 'style')
    style.textContent = 'html, body { margin: 0; padding: 0; height: 100%; } '
        + 'body > svg { display: block; width: 100%; height: 100%; }'
    head.append(style)
    const body = doc.createElementNS(XHTML_NS, 'body')
    body.append(doc.importNode(svg, true))
    doc.documentElement.append(head, body)
    return new XMLSerializer().serializeToString(doc)
}

// `asPage`: an SVG that is a section of its own (shown in a frame, not as an image).
export const sanitizeMarkup = (text, type, asPage = false) => {
    const parser = new DOMParser()
    let doc = parser.parseFromString(text, type)
    if (type !== 'text/html' && doc.querySelector('parsererror')) {
        type = 'text/html'
        doc = parser.parseFromString(text, type)
    }
    if (type === 'application/xml') {
        const root = doc.documentElement
        if (root?.namespaceURI === XHTML_NS && root.localName === 'html') type = 'application/xhtml+xml'
        else if (root?.namespaceURI === 'http://www.w3.org/2000/svg') type = 'image/svg+xml'
        // Other XML has no body to lay out: show its text.
        else return { text: normalizeSpace(root?.textContent ?? ''), type: 'text/plain' }
    }
    sanitizeDocument(doc, type !== 'image/svg+xml')
    if (type === 'image/svg+xml' && asPage)
        return { text: svgPage(doc), type: 'application/xhtml+xml' }
    return { text: new XMLSerializer().serializeToString(doc), type }
}

// foliate's loaders announce every resource they turn into a blob URL with a `data`
// event (EPUB: all of them; KF8: resources). Clean markup on the way through.
// `sections`: the hrefs of the book's own sections (`detail.name` is the href).
const resourceFilter = (sections = new Set()) => ({ detail }) => {
    const type = String(detail.type ?? '').split(';')[0].trim().toLowerCase()
    if (type === 'text/css') {
        // (foliate's paginator rewrites CSS too, after this)
        detail.data = Promise.resolve(detail.data).then(toText).then(cleanCSS)
        return
    }
    const markup = markupType(type)
    if (markup) {
        const asPage = markup === 'image/svg+xml' && sections.has(detail.name)
        const result = Promise.resolve(detail.data).then(toText)
            .then(text => sanitizeMarkup(text, markup, asPage))
        detail.data = result.then(r => r.text)
        detail.type = result.then(r => r.type)
    } else if (!type) {
        // No media type: a browser would sniff markup into a page, so clean it as one.
        const result = Promise.resolve(detail.data).then(async data => {
            const text = await toText(data)
            return /^\s*</.test(text) ? sanitizeMarkup(text, 'text/html') : { text: data, type: '' }
        })
        detail.data = result.then(r => r.text)
        detail.type = result.then(r => r.type)
    } else if (!isInertType(type)) detail.type = 'text/plain'
}

// MOBI and KF8 build their sections with the book's own DOMParser.
const sanitizingParser = parser => ({
    parseFromString(str, type) {
        const doc = parser.parseFromString(str, type)
        const t = String(type).toLowerCase()
        if (/html|svg/.test(t) && !doc.querySelector('parsererror'))
            sanitizeDocument(doc, !t.includes('svg'))
        return doc
    },
})

// ---------------------------------------------------------------------------
// Formats, protection and KFX.
// ---------------------------------------------------------------------------

const KFX_EXTENSIONS = new Set(['kfx', 'azw8', 'kpf'])
const FONT_OBFUSCATION = new Set([
    'http://www.idpf.org/2008/embedding',
    'http://ns.adobe.com/pdf/enc#RC',
])
const isFontPath = path => /\.(ttf|otf|ttc|woff2?|eot|pfb|pfm|dfont)$/i.test(path ?? '')
const ascii = (bytes, start, end) => String.fromCharCode(...bytes.subarray(start, end))

export const sniff = head => {
    if (head.length >= 4 && ascii(head, 0, 4) === 'CONT') return 'kfx'
    if (head.length >= 8 && head[0] === 0xea && ascii(head, 1, 7) === 'DRMION' && head[7] === 0xee)
        return 'kfx'
    if (head.length >= 4 && head[0] === 0x50 && head[1] === 0x4b && head[2] === 0x03 && head[3] === 0x04)
        return 'zip'
    if (head.length >= 68 && ascii(head, 60, 68) === 'BOOKMOBI') return 'mobi'
    return null
}

// A MOBI, AZW or AZW3 is protected when record 0's PalmDOC header says it's encrypted.
export const mobiEncryption = async file => {
    const header = new Uint8Array(await file.slice(0, 86).arrayBuffer())
    if (header.length < 86) throw new ReaderError(DAMAGED, 'Truncated PDB header')
    const dv = new DataView(header.buffer, header.byteOffset, header.byteLength)
    if (dv.getUint16(76) < 1) throw new ReaderError(DAMAGED, 'No records')
    const record0 = dv.getUint32(78)
    const palmdoc = new Uint8Array(await file.slice(record0, record0 + 16).arrayBuffer())
    if (palmdoc.length < 14) throw new ReaderError(DAMAGED, 'Truncated record 0')
    return new DataView(palmdoc.buffer, palmdoc.byteOffset).getUint16(12)
}

// An EPUB is protected when it carries a DRM licence, or encryption.xml encrypts
// anything but fonts with something other than the two font obfuscations.
export const epubProtection = (names, encryptionXML) => {
    const lower = new Set([...names].map(n => n.toLowerCase()))
    if (['meta-inf/rights.xml', 'meta-inf/sinf.xml', 'meta-inf/license.lcpl']
        .some(n => lower.has(n))) return true
    if (!encryptionXML) return false
    const doc = new DOMParser().parseFromString(encryptionXML, 'application/xml')
    // foliate-js refuses a broken encryption.xml itself; that reads as damaged
    if (doc.querySelector('parsererror')) return false
    for (const data of doc.getElementsByTagNameNS('*', 'EncryptedData')) {
        const algorithm = data.getElementsByTagNameNS('*', 'EncryptionMethod')[0]
            ?.getAttribute('Algorithm')?.trim()
        const uri = data.getElementsByTagNameNS('*', 'CipherReference')[0]
            ?.getAttribute('URI')
        if (FONT_OBFUSCATION.has(algorithm)) continue
        let path = uri ?? ''
        try { path = decodeURI(path) } catch { /* keep as is */ }
        if (!isFontPath(path)) return true
    }
    return false
}

const IMAGE_EXTENSION = /\.(jpe?g|png|gif|bmp|webp|svg|jxl|avif)$/i

const makeZipLoader = async file => {
    const { configure, ZipReader, BlobReader, TextWriter, BlobWriter } =
        await import('./foliate/vendor/zip.js')
    configure({ useWebWorkers: false })
    const reader = new ZipReader(new BlobReader(file))
    const entries = (await reader.getEntries()).filter(entry => !entry.directory)
    const map = new Map(entries.map(entry => [entry.filename, entry]))
    const load = f => (name, ...args) => map.has(name) ? f(map.get(name), ...args) : null
    const loadText = load(entry => entry.getData(new TextWriter()))
    const loadBlob = load((entry, type) => entry.getData(new BlobWriter(type)))
    const getSize = name => map.get(name)?.uncompressedSize ?? 0
    return { entries, names: [...map.keys()], loadText, loadBlob, getSize }
}

// comic-book.js only knows lower-case image extensions; scans often use upper case.
const makeComic = async (loader, name) => {
    const { makeComicBook } = await import('./foliate/comic-book.js')
    const alias = new Map()
    const entries = []
    for (const filename of loader.names) {
        const base = filename.split('/').pop()
        if (filename.startsWith('__MACOSX/') || base.startsWith('.')) continue
        const match = IMAGE_EXTENSION.exec(filename)
        if (!match) continue
        const lower = filename.slice(0, -match[0].length) + match[0].toLowerCase()
        if (lower !== filename) alias.set(lower, filename)
        entries.push({ filename: lower })
    }
    const real = n => alias.get(n) ?? n
    const book = makeComicBook({
        entries,
        loadBlob: (n, ...args) => loader.loadBlob(real(n), ...args),
        getSize: n => loader.getSize(real(n)),
    }, { name })
    book.metadata = { title: name.replace(/\.[^.]+$/, '') }
    book.toc = [] // a list of image names doesn't help anyone
    return book
}

const openEPUB = async loader => {
    const { EPUB } = await import('./foliate/epub.js')
    const book = await new EPUB({
        loadText: loader.loadText,
        loadBlob: loader.loadBlob,
        getSize: loader.getSize,
        sha1,
    }).init()
    // Scripts never load, and markup is cleaned before it becomes a blob URL.
    book.transformTarget?.addEventListener('load', ({ detail }) => {
        if (detail.isScript) detail.allow = false
    })
    book.transformTarget?.addEventListener('data',
        resourceFilter(new Set(book.sections.map(section => section.id))))
    return book
}

const openMOBI = async file => {
    if (await mobiEncryption(file) !== 0) throw new ReaderError(PROTECTED)
    const [{ MOBI }, fflate] = await Promise.all([
        import('./foliate/mobi.js'),
        import('./foliate/vendor/fflate.js'),
    ])
    const book = await new MOBI({ unzlib: fflate.unzlibSync }).open(file)
    // a combined MOBI/KF8 file: the KF8 part has its own header
    if (book.mobi?.headers?.palmdoc?.encryption) throw new ReaderError(PROTECTED)
    book.parser = sanitizingParser(book.parser)
    book.transformTarget?.addEventListener('data', resourceFilter())
    return book
}

const makeBook = async (file, name) => {
    const extension = name.toLowerCase().split('.').pop()
    const head = new Uint8Array(await file.slice(0, 68).arrayBuffer())
    const kind = sniff(head)
    if (kind === 'kfx') throw new ReaderError(KFX)
    if (kind === 'zip') {
        const loader = await makeZipLoader(file)
        if (extension === 'cbz') return makeComic(loader, name)
        const encryption = loader.names.includes('META-INF/encryption.xml')
            ? await loader.loadText('META-INF/encryption.xml') : null
        if (epubProtection(loader.names, encryption)) throw new ReaderError(PROTECTED)
        if (loader.names.includes('META-INF/container.xml')) return openEPUB(loader)
        if (loader.names.some(n => IMAGE_EXTENSION.test(n))) return makeComic(loader, name)
        throw new ReaderError(DAMAGED, 'Not an EPUB')
    }
    if (kind === 'mobi') return openMOBI(file)
    throw new ReaderError(DAMAGED, 'Unknown format')
}

// ---------------------------------------------------------------------------
// Positions and settings (this browser only).
// ---------------------------------------------------------------------------

const readJSON = key => {
    try {
        const value = JSON.parse(localStorage.getItem(key))
        return value && typeof value === 'object' && !Array.isArray(value) ? value : {}
    } catch {
        return {}
    }
}

// The console talks to more than one server, so each keeps its own positions: the key
// is `clouddrive.bookPositions:<server URL>`, made by the Rust side (book_positions.rs).
export const readPositions = (key = POSITIONS_KEY) => readJSON(key)

const savePosition = (key, path, cfi, fraction) => {
    if (!path || !cfi || !Number.isFinite(fraction)) return
    const all = readPositions(key)
    // rounded down, like every percent shown for it
    all[path] = { cfi, fraction: Math.floor(Math.min(Math.max(fraction, 0), 1) * 1e6) / 1e6, at: Date.now() }
    const keys = Object.keys(all)
    if (keys.length > MAX_POSITIONS) {
        keys.sort((a, b) => (all[a]?.at ?? 0) - (all[b]?.at ?? 0))
        for (const key of keys.slice(0, keys.length - MAX_POSITIONS)) delete all[key]
    }
    try {
        localStorage.setItem(key, JSON.stringify(all))
    } catch { /* storage full or blocked: the place just isn't kept */ }
}

const DEFAULT_SETTINGS = {
    fontSize: 100,
    theme: 'auto',
    flow: 'paginated',
    lineHeight: 1.5,
    margin: 'medium',
}

const normalizeSettings = value => {
    const s = { ...DEFAULT_SETTINGS, ...(value ?? {}) }
    s.fontSize = Math.min(250, Math.max(70, Math.round(Number(s.fontSize) || 100)))
    if (!['auto', 'white', 'sepia', 'dark', 'black'].includes(s.theme)) s.theme = 'auto'
    if (s.flow !== 'scrolled') s.flow = 'paginated'
    s.lineHeight = [1.3, 1.5, 1.8].includes(Number(s.lineHeight)) ? Number(s.lineHeight) : 1.5
    if (!['narrow', 'medium', 'wide'].includes(s.margin)) s.margin = 'medium'
    return s
}

export const readSettings = () => normalizeSettings(readJSON(SETTINGS_KEY))

// { continuous, twoPages, cover }; continuous falls back to the old `flow` setting.
const normalizeLayout = (value, settings) => {
    if (typeof value === 'string') try {
        value = JSON.parse(value)
    } catch {
        value = null
    }
    return {
        continuous: typeof value?.continuous === 'boolean' ? value.continuous
            : settings?.flow === 'scrolled',
        twoPages: value?.twoPages !== false,
        cover: value?.cover !== false,
    }
}

// Each theme's text and links reach at least 4.5:1 on its background.
const THEMES = {
    white: { bg: '#FFFFFF', fg: '#1C1C1E', link: '#0B57D0', dark: false },
    sepia: { bg: '#F4ECD8', fg: '#4A3B2C', link: '#7A3E00', dark: false },
    dark: { bg: '#1E1E20', fg: '#D8D8DC', link: '#8AB4F8', dark: true },
    black: { bg: '#000000', fg: '#C8C8C8', link: '#8AB4F8', dark: true },
}
const resolveTheme = name => THEMES[name]
    ?? (document.documentElement.getAttribute('data-theme') === 'dark' ? THEMES.dark : THEMES.white)

const MARGINS = {
    narrow: { gap: '4%', maxInline: '820px' },
    medium: { gap: '7%', maxInline: '720px' },
    wide: { gap: '12%', maxInline: '640px' },
}

const bookCSS = (s, t) => `
    @namespace epub "http://www.idpf.org/2007/ops";
    html {
        color-scheme: ${t.dark ? 'dark' : 'light'};
        -webkit-text-size-adjust: none;
        text-size-adjust: none;
    }
    /* The theme colour is body's and html stays transparent, so body's background
       (the colour, and a cover drawn as its background image) fills the whole page. */
    html {
        background-color: transparent !important;
    }
    body {
        background-color: ${t.bg} !important;
    }
    /* The book's page margins give way to the reader's margin setting (plan §5.5). The
       paginator already sets body's margin; its padding on the line sides goes too. */
    body {
        padding-inline: 0 !important;
    }
    html, body {
        color: ${t.fg} !important;
    }
    ${t.dark ? `body *:not(a) {
        color: inherit !important;
        background-color: transparent !important;
        border-color: currentColor !important;
    }` : ''}
    a:any-link, a:any-link * {
        color: ${t.link} !important;
    }
    p, li, blockquote, dd, dt {
        line-height: ${s.lineHeight} !important;
        -webkit-hyphens: auto;
        hyphens: auto;
        widows: 2;
        orphans: 2;
    }
    [align="left"] { text-align: left; }
    [align="right"] { text-align: right; }
    [align="center"] { text-align: center; }
    [align="justify"] { text-align: justify; }
    pre {
        white-space: pre-wrap !important;
    }
    aside[epub|type~="endnote"],
    aside[epub|type~="footnote"],
    aside[epub|type~="note"],
    aside[epub|type~="rearnote"] {
        display: none;
    }
`

// ---------------------------------------------------------------------------
// Footnotes (detection after foliate-js's footnotes.js, MIT).
// ---------------------------------------------------------------------------

const OPS_NS = 'http://www.idpf.org/2007/ops'
const epubTypes = el => new Set((el?.getAttributeNS?.(OPS_NS, 'type')
    || el?.getAttribute?.('epub:type') || '').split(/\s+/).filter(Boolean))
const roles = el => new Set((el?.getAttribute?.('role') ?? '').split(/\s+/).filter(Boolean))

const isSuperscript = el => {
    if (!el) return false
    if (el.matches('sup')) return true
    const align = el.ownerDocument.defaultView?.getComputedStyle(el)?.verticalAlign ?? ''
    return align === 'super' || align === 'top' || align === 'text-top' || /^\d/.test(align)
}

// 'yes', 'maybe' or null
const footnoteKind = a => {
    const types = epubTypes(a)
    const r = roles(a)
    if (['noteref', 'biblioref', 'glossref'].some(t => types.has(t))
        || ['doc-noteref', 'doc-biblioref', 'doc-glossref'].some(t => r.has(t))
        // 多看 (Duokan) and QQ Reader footnotes
        || a.classList?.contains('duokan-footnote')
        || a.querySelector?.('img.duokan-footnote, img.qqreader-footnote')) return 'yes'
    if (types.has('backlink') || r.has('doc-backlink')) return null
    if (isSuperscript(a) || (a.children.length === 1 && isSuperscript(a.children[0]))
        || isSuperscript(a.parentElement)) return 'maybe'
    return null
}

const INLINE = 'a, span, sup, sub, em, strong, i, b, small, big'
const FOCUSABLE = 'a[href], area[href], button, input, select, textarea, summary, '
    + '[tabindex]:not([tabindex="-1"])'
const footnoteBlock = target => {
    let el = target
    while (el.matches?.(INLINE) && el.parentElement) el = el.parentElement
    if (el === el.ownerDocument.body) {
        const sibling = target.nextElementSibling
        if (sibling && !sibling.matches(INLINE)) return sibling
        return null
    }
    return el
}

const normalizeSpace = s => (s ?? '').replace(/\s+/g, ' ').trim()
const BLOCKS = 'p, li, dd, dt, blockquote, div, h1, h2, h3, h4, h5, h6'
const blockText = el => {
    const leaves = [...el.querySelectorAll(BLOCKS)].filter(b => !b.querySelector(BLOCKS))
    const parts = leaves.length ? leaves.map(b => normalizeSpace(b.textContent))
        : [normalizeSpace(el.textContent)]
    return parts.filter(Boolean).join('\n\n').slice(0, 4000)
}

// ---------------------------------------------------------------------------
// The reader.
// ---------------------------------------------------------------------------

const formatLanguageMap = x => {
    if (!x) return ''
    if (typeof x === 'string') return x
    const values = Object.values(x)
    return typeof values[0] === 'string' ? values[0] : ''
}

const serializeTOC = (items, depth = 0) => (Array.isArray(items) ? items : [])
    .filter(item => item && (item.label || item.subitems?.length))
    .map(item => ({
        id: Number.isInteger(item.id) ? item.id : -1,
        label: normalizeSpace(String(item.label ?? '')) || '…',
        href: typeof item.href === 'string' ? item.href : null,
        subitems: depth < 8 ? serializeTOC(item.subitems, depth + 1) : [],
    }))

let current = null

class Session {
    closed = false
    userMoved = false
    ready = false
    networkFailed = false
    controller = new AbortController()
    saveTimer = 0
    wheelDelta = 0
    wheelLocked = false
    title = ''
    fontBases = new WeakMap() // section document → the book's own root font size (px)
    constructor(container, opts) {
        this.container = container
        this.opts = opts
        this.path = String(opts.path ?? '')
        this.name = String(opts.name ?? 'book')
        // positions are kept per server (see readPositions)
        this.positionsKey = typeof opts.positionsKey === 'string' && opts.positionsKey
            ? opts.positionsKey : POSITIONS_KEY
        let settings = opts.settings
        if (typeof settings === 'string') try {
            settings = JSON.parse(settings)
        } catch {
            settings = null
        }
        this.settings = settings ? normalizeSettings(settings) : readSettings()
        // Page layout, kept per book by the Rust side: continuous scrolling, two pages,
        // the cover on its own. Without it (older callers), `settings.flow` decides.
        this.layoutFromSettings = !opts.layout
        this.layout = normalizeLayout(opts.layout, this.settings)
    }
    emit(type, detail) {
        if (this.closed) return
        try {
            this.opts.onEvent?.(type, detail ?? null)
        } catch (e) {
            console.warn(e)
        }
    }
    async open() {
        const extension = this.name.toLowerCase().split('.').pop()
        if (KFX_EXTENSIONS.has(extension)) throw new ReaderError(KFX)
        this.file = await openFile({
            url: this.opts.url,
            name: this.name,
            size: Number(this.opts.size) || 0,
            signal: this.controller.signal,
            onNetworkError: () => this.onNetworkError(),
        })
        this.check()
        this.book = await makeBook(this.file, this.name)
        this.check()
        this.title = formatLanguageMap(this.book.metadata?.title).trim()
            || this.name.replace(/\.[^.]+$/, '')

        // How a fixed-layout book pairs its pages, as the book says (see pair()).
        this.fixedLayout = this.book.rendition?.layout === 'pre-paginated'
        this.bookSpread = this.book.rendition?.spread
        this.bookPageSpreads = this.book.sections.map(section => section.pageSpread)
        if (this.fixedLayout) this.pairing = this.pair()

        const view = await this.mountView()
        this.view = view
        this.container.addEventListener('click', this.onContainerClick)
        this.container.addEventListener('wheel', this.onWheel, { passive: true })
        addEventListener('resize', this.onResize)
        this.applySettings(this.settings)
        this.themeObserver = new MutationObserver(() => {
            if (this.settings.theme === 'auto') this.applyStyles()
        })
        this.themeObserver.observe(document.documentElement,
            { attributes: true, attributeFilter: ['data-theme'] })
        addEventListener('pagehide', this.flush)
        document.addEventListener('visibilitychange', this.onVisibilityChange)

        await this.restore(this.opts.saved ?? readPositions(this.positionsKey)[this.path])
        this.check()
        if (!view.lastLocation) throw new ReaderError(this.networkFailed ? NETWORK : DAMAGED,
            'Nothing could be shown')
        this.ready = true

        const { book } = this
        return {
            title: this.title,
            dir: book.dir === 'rtl' ? 'rtl' : 'ltr',
            fixedLayout: !!view.isFixedLayout,
            language: view.language?.canonical ?? '',
            toc: serializeTOC(book.toc),
            location: this.location(),
        }
    }
    // Back to the saved place: its CFI; when that no longer finds its place (the file
    // changed), the saved fraction (docs/EBOOK_READER.md §9.2, step 4); else the
    // beginning.
    async restore(saved) {
        const { view } = this
        const cfi = typeof saved?.cfi === 'string' && saved.cfi ? saved.cfi : null
        const fraction = Number.isFinite(saved?.fraction) ? saved.fraction : null
        const attempt = async go => {
            try {
                await go()
            } catch (e) {
                this.check()
                console.warn(e)
            }
            this.check()
        }
        if (cfi && this.resolvesTo(cfi)) {
            await attempt(() => view.init({ lastLocation: cfi }))
            if (view.lastLocation && this.landedOn(cfi)) return
        }
        if (fraction !== null) {
            await attempt(() => view.goToFraction(fraction))
            if (view.lastLocation) return
        }
        if (!view.lastLocation) await attempt(() => view.init({ lastLocation: null }))
    }
    // The CFI names a section this book has.
    resolvesTo(cfi) {
        const target = this.view.resolveNavigation(cfi)
        return Number.isInteger(target?.index) && target.index >= 0
            && target.index < this.book.sections.length
    }
    // The page shown is the CFI's own place, not just the start of its section.
    landedOn(cfi) {
        if (this.view.isFixedLayout) return true
        try {
            const { anchor } = this.view.resolveNavigation(cfi) ?? {}
            const doc = this.view.renderer.getContents?.()[0]?.doc
            return !!(doc && typeof anchor === 'function' && anchor(doc))
        } catch {
            return false
        }
    }
    check() {
        if (this.closed) throw new ReaderError('CLOSED', 'Closed')
    }
    // A foliate view of the book, with the reader's listeners; events from a view that
    // has since been replaced (see relayout) are ignored.
    async mountView() {
        const view = document.createElement('foliate-view')
        Object.assign(view.style, { display: 'block', width: '100%', height: '100%' })
        // (a closed or replaced view may still be here for a moment, hidden)
        this.container.append(view)
        try {
            await view.open(this.book)
            // Let the renderer lay itself out before the first section loads: foliate's
            // paginator otherwise may lay out a frame whose document isn't parsed yet.
            await nextFrames()
            this.check()
        } catch (e) {
            this.retireView(view)
            throw e
        }
        const mine = handler => e => {
            if (this.view === view) handler(e)
        }
        view.addEventListener('load', mine(e => this.onLoad(e.detail)))
        view.addEventListener('link', mine(e => this.onLink(e)))
        view.addEventListener('external-link', mine(e => this.onExternalLink(e)))
        // The renderer's own event carries the reason (page turn, scroll, layout…).
        view.renderer.addEventListener('relocate', mine(e => this.onRelocate(e.detail)))
        return view
    }
    // foliate's renderer may still have frame callbacks queued that expect its frame in
    // place: hide a view now and take it down two frames later.
    retireView(view, then) {
        Object.assign(view.style, { position: 'absolute', inset: '0', visibility: 'hidden' })
        view.inert = true
        nextFrames().then(() => {
            try { view.close() } catch { /* never rendered */ }
            view.remove()
            then?.()
        })
    }
    // Two pages side by side: chosen, not scrolling, and a landscape window at least
    // 600 px wide (as in the apps).
    twoUp() {
        return this.layout.twoPages && !this.continuous()
            && innerWidth >= 600 && innerWidth > innerHeight
    }
    // Continuous scrolling; fixed-layout books and comics only turn pages.
    continuous() {
        return this.layout.continuous && !this.fixedLayout
    }
    // How foliate's fixed-layout renderer pairs pages comes from the book: its
    // `rendition.spread` and each section's `pageSpread`. One page at a time is spread
    // `none`. Two pages with the cover on its own pair [0] [1,2] [3,4]… (or follow the
    // book's own page-spread hints when it has them); without it, [0,1] [2,3]….
    pair() {
        const { book } = this
        book.rendition ??= {}
        if (!this.twoUp()) {
            book.rendition.spread = 'none'
            return 'single'
        }
        book.rendition.spread = this.bookSpread === 'none' ? 'auto' : this.bookSpread
        const rtl = book.dir === 'rtl'
        const recto = rtl ? 'left' : 'right'
        const verso = rtl ? 'right' : 'left'
        const hinted = this.bookPageSpreads.some(Boolean)
        book.sections.forEach((section, i) => {
            section.pageSpread = this.layout.cover
                ? (hinted ? this.bookPageSpreads[i] : i % 2 ? verso : recto)
                : (i % 2 ? recto : verso)
        })
        return this.layout.cover ? 'cover' : 'pairs'
    }
    // A fixed-layout book changes how it pairs pages: foliate builds its spreads when it
    // opens a book, so a new view takes over at the same page.
    relayout() {
        this.relayouting = (this.relayouting ?? Promise.resolve()).then(async () => {
            if (this.closed || !this.view) return
            const pairing = this.pair()
            if (pairing === this.pairing) return
            this.pairing = pairing
            const old = this.view
            const index = old.renderer?.index
            const view = await this.mountView()
            this.view = view
            await view.goTo(Number.isInteger(index) && index >= 0 ? index : 0)
            this.retireView(old)
        }).catch(e => {
            if (!this.closed) console.warn(e)
        })
        return this.relayouting
    }
    // Continuous scrolling and the number of columns (paginator), or the page pairing
    // (fixed layout).
    applyLayout() {
        const renderer = this.view?.renderer
        if (!renderer) return
        if (this.fixedLayout) return this.relayout()
        const margin = MARGINS[this.settings.margin]
        const two = this.twoUp()
        // foliate makes a second column only when a page is wider than max-inline-size
        const width = this.container.getBoundingClientRect().width
        const column = Math.min(parseFloat(margin.maxInline), Math.floor(width / 2))
        // (each change lays the book out again; flow and max-inline-size do it themselves)
        const set = (name, value) => {
            if (renderer.getAttribute(name) === value) return false
            renderer.setAttribute(name, value)
            return true
        }
        const gap = set('gap', margin.gap)
        const columns = set('max-column-count', two ? '2' : '1')
        const flow = set('flow', this.continuous() ? 'scrolled' : 'paginated')
        const inline = set('max-inline-size', two ? `${column}px` : margin.maxInline)
        if ((gap || columns) && !flow && !inline) renderer.render?.()
    }
    onResize = () => {
        clearTimeout(this.resizeTimer)
        this.resizeTimer = setTimeout(() => this.applyLayout(), 150)
    }
    onNetworkError() {
        this.networkFailed = true
        if (this.ready) this.emit('readerror', { code: NETWORK })
    }
    location() {
        const loc = this.view?.lastLocation
        if (!loc) return null
        return {
            fraction: Number.isFinite(loc.fraction) ? loc.fraction : 0,
            tocId: Number.isInteger(loc.tocItem?.id) ? loc.tocItem.id : -1,
            tocLabel: normalizeSpace(loc.tocItem?.label ?? ''),
            pageLabel: normalizeSpace(String(loc.pageItem?.label ?? '')),
            ...this.edges(),
        }
    }
    // Whether Previous and Next can go anywhere. foliate's paginator knows; its
    // fixed-layout renderer (CBZ, fixed-layout EPUB) doesn't, so work it out from the
    // section shown and the spreads.
    edges() {
        const renderer = this.view?.renderer
        if (!renderer) return { atStart: false, atEnd: false }
        if (!this.view.isFixedLayout) return { atStart: !!renderer.atStart, atEnd: !!renderer.atEnd }
        const { sections } = this.book
        const linear = sections.flatMap((section, i) => section.linear === 'no' ? [] : [i])
        const first = linear[0] ?? 0
        const last = linear.at(-1) ?? sections.length - 1
        const index = renderer.index
        if (!Number.isInteger(index) || index < 0) return { atStart: false, atEnd: false }
        // Two pages side by side: Previous and Next move a whole spread.
        const shown = (renderer.getContents?.() ?? []).filter(({ doc }) => {
            const frame = doc?.defaultView?.frameElement
            return frame && frame.style.display !== 'none'
                && frame.parentElement?.style.display !== 'none'
        }).length
        if (shown > 1) {
            const spread = i => renderer.getSpreadOf?.(sections[i])?.index
            const current = spread(index)
            return { atStart: current === spread(first), atEnd: current === spread(last) }
        }
        return { atStart: index <= first, atEnd: index >= last }
    }
    onRelocate(detail) {
        // A move made by the person counts; laying the page out again doesn't.
        if (this.ready && detail?.reason !== 'anchor') this.userMoved = true
        const location = this.location()
        if (!location) return
        this.emit('relocate', location)
        if (this.userMoved) this.scheduleSave()
    }
    scheduleSave() {
        clearTimeout(this.saveTimer)
        this.saveTimer = setTimeout(this.flush, 800)
    }
    flush = () => {
        clearTimeout(this.saveTimer)
        this.saveTimer = 0
        if (!this.userMoved) return
        const loc = this.view?.lastLocation
        if (loc?.cfi) savePosition(this.positionsKey, this.path, loc.cfi, loc.fraction)
    }
    onVisibilityChange = () => {
        if (document.visibilityState === 'hidden') this.flush()
    }
    applySettings(settings) {
        this.settings = normalizeSettings(settings)
        const renderer = this.view?.renderer
        if (!renderer) return
        if (this.layoutFromSettings) this.layout.continuous = this.settings.flow === 'scrolled'
        if (!this.view.isFixedLayout) {
            renderer.setAttribute('margin', '48px')
            this.applyLayout()
            if (matchMedia('(prefers-reduced-motion: reduce)').matches)
                renderer.removeAttribute('animated')
            else renderer.setAttribute('animated', '')
            for (const { doc } of renderer.getContents?.() ?? []) this.applyFontSize(doc)
        }
        this.applyStyles()
    }
    applyStyles() {
        this.view?.renderer?.setStyles?.(bookCSS(this.settings, resolveTheme(this.settings.theme)))
    }
    // The font size scales the book's own root size, so a book that sets
    // `html { font-size: 62.5% }` and sizes its text in rem keeps its proportions.
    applyFontSize(doc) {
        const root = doc?.documentElement
        if (!root?.style || this.view?.isFixedLayout) return
        let base = this.fontBases.get(doc)
        if (base === undefined) {
            root.style.removeProperty('font-size')
            base = parseFloat(doc.defaultView?.getComputedStyle(root)?.fontSize) || 16
            this.fontBases.set(doc, base)
        }
        root.style.setProperty('font-size',
            `${(base * this.settings.fontSize / 100).toFixed(2)}px`, 'important')
    }
    // foliate copies the section's html/body background onto its own element in the
    // page, where the section's Content-Security-Policy doesn't apply. Pin both to the
    // background image they have now, kept only when it is the book's own (blob:,
    // data:), so neither a CSS escape the cleaning missed nor a later rule (:hover,
    // :focus-within) can put another URL there. (Runs before foliate copies it.)
    pinBackgrounds(doc) {
        for (const el of [doc.documentElement, doc.body]) {
            if (!el?.style) continue
            const image = doc.defaultView?.getComputedStyle(el)?.backgroundImage || 'none'
            const urls = [...image.matchAll(CSS_STRING)].map(m => m[2])
            const own = urls.every(isBookURL) && !/url\(\s*[^"'\s)]/i.test(image)
            el.style.setProperty('background-image', own ? image : 'none', 'important')
        }
    }
    onLoad({ doc }) {
        const frame = doc.defaultView?.frameElement
        if (frame && this.title) frame.setAttribute('title', this.title)
        this.applyFontSize(doc)
        this.pinBackgrounds(doc)
        doc.addEventListener('keydown', e => e.key === 'Tab' ? this.onFrameTab(doc, e) : this.forwardKey(e))
        doc.addEventListener('click', e => this.onDocClick(doc, e))
        doc.addEventListener('wheel', this.onWheel, { passive: true })
    }
    // Tab moves through the links in the book's frame; past the first or the last of
    // them it goes to the reader's own controls, so focus never leaves the dialog.
    onFrameTab(doc, e) {
        const links = [...doc.querySelectorAll(FOCUSABLE)]
            .filter(el => !el.disabled && el.getClientRects().length > 0)
        const at = links.indexOf(doc.activeElement)
        const leaving = e.shiftKey ? at <= 0 : at === links.length - 1 || !links.length
        if (!leaving) return
        e.preventDefault()
        const dialog = this.container.closest('[role="dialog"]')
        if (!dialog) return
        if (e.shiftKey && dialog.tabIndex >= 0) {
            dialog.focus()
            return
        }
        const controls = [...dialog.querySelectorAll(FOCUSABLE)].filter(el => !el.disabled
            && !this.container.contains(el) && el.getClientRects().length > 0)
        const after = controls.filter(el =>
            this.container.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING)
        const target = e.shiftKey ? controls.at(-1) : after[0] ?? controls[0]
        target?.focus()
    }
    // Keys pressed in the book's frame reach the reader's own handler.
    forwardKey(e) {
        if (e.key === 'Tab' || e.isComposing) return
        if (e.target?.closest?.('input, textarea, select, [contenteditable=""], [contenteditable="true"]'))
            return
        const copy = new KeyboardEvent('keydown', {
            key: e.key, code: e.code, location: e.location, repeat: e.repeat,
            shiftKey: e.shiftKey, ctrlKey: e.ctrlKey, altKey: e.altKey, metaKey: e.metaKey,
            bubbles: true, cancelable: true, composed: true,
        })
        this.container.dispatchEvent(copy)
        if (copy.defaultPrevented) e.preventDefault()
    }
    onDocClick(doc, e) {
        if (e.defaultPrevented || e.button !== 0 || e.detail > 1) return
        if (e.target?.closest?.('a[href], button, input, select, textarea, label, summary, audio, video'))
            return
        const selection = doc.getSelection?.()
        if (selection && !selection.isCollapsed) return
        const frame = doc.defaultView?.frameElement
        if (!frame) return
        const rect = frame.getBoundingClientRect()
        const scale = frame.offsetWidth ? rect.width / frame.offsetWidth : 1
        this.tap(rect.left + e.clientX * scale)
    }
    onContainerClick = e => {
        if (e.defaultPrevented || e.button !== 0 || e.detail > 1) return
        if (!this.view || (e.target !== this.view && !this.view.contains(e.target))) return
        this.tap(e.clientX)
    }
    // Side thirds turn the page; the middle shows or hides the bars.
    tap(x) {
        const rect = this.container.getBoundingClientRect()
        if (!rect.width) return
        const at = (x - rect.left) / rect.width
        if (at < 0.3) this.turn('left')
        else if (at > 0.7) this.turn('right')
        else this.emit('middle')
    }
    turn(side) {
        if (!this.view) return
        this.emit('turn', { side })
        if (side === 'left') this.view.goLeft()
        else this.view.goRight()
    }
    onWheel = e => {
        if (!this.view || this.continuous()) return
        if (e.ctrlKey) return // pinch zoom
        const delta = Math.abs(e.deltaY) >= Math.abs(e.deltaX) ? e.deltaY : e.deltaX
        if (this.wheelLocked) return
        this.wheelDelta += delta
        if (Math.abs(this.wheelDelta) < 60) return
        const forward = this.wheelDelta > 0
        this.wheelDelta = 0
        this.wheelLocked = true
        setTimeout(() => { this.wheelLocked = false; this.wheelDelta = 0 }, 450)
        if (forward) this.view.next()
        else this.view.prev()
    }
    onLink(e) {
        const { a, href } = e.detail
        let kind = null
        try { kind = footnoteKind(a) } catch { /* not a footnote */ }
        if (!kind) return
        e.preventDefault()
        this.showFootnote(href, kind).catch(() => this.view?.goTo(href))
    }
    async showFootnote(href, kind) {
        const { book } = this
        const target = await book.resolveHref(href)
        if (!target || !(target.index >= 0)) throw new Error('No target')
        const doc = await book.sections[target.index]?.createDocument?.()
        if (!doc) throw new Error('No document')
        let el = target.anchor(doc)
        if (!el || typeof el !== 'object' || !el.nodeType) throw new Error('No anchor')
        if (kind === 'maybe' || el.matches?.(INLINE)) el = footnoteBlock(el)
        const text = el ? blockText(el) : ''
        if (!text) throw new Error('Empty note')
        this.emit('footnote', { text, href })
    }
    onExternalLink(e) {
        e.preventDefault()
        const href = String(e.detail?.href_ ?? e.detail?.href ?? '').trim()
        if (/^(https?|mailto):/i.test(href)) this.emit('external', { href })
    }
    command(name, arg) {
        const view = this.view
        if (!view || !this.ready) return
        switch (name) {
            case 'next': return view.next(arg ?? undefined)
            case 'prev': return view.prev(arg ?? undefined)
            case 'left': return view.goLeft()
            case 'right': return view.goRight()
            case 'start': return view.goToFraction(0)
            case 'end': return view.goToFraction(1)
            case 'fraction': {
                const f = Number(arg)
                if (Number.isFinite(f)) return view.goToFraction(Math.min(Math.max(f, 0), 1))
                return
            }
            case 'href': return typeof arg === 'string' ? view.goTo(arg) : undefined
            case 'settings': {
                let settings = arg
                if (typeof settings === 'string') try {
                    settings = JSON.parse(settings)
                } catch {
                    return
                }
                return this.applySettings(settings)
            }
            case 'focus': return view.renderer?.focusView?.()
            case 'layout': {
                let layout = arg
                if (typeof layout === 'string') try {
                    layout = JSON.parse(layout)
                } catch {
                    return
                }
                this.layoutFromSettings = false
                this.layout = normalizeLayout(layout, this.settings)
                return this.applyLayout()
            }
        }
    }
    close() {
        if (this.closed) return
        this.flush()
        this.closed = true
        this.controller.abort()
        removeEventListener('pagehide', this.flush)
        removeEventListener('resize', this.onResize)
        clearTimeout(this.resizeTimer)
        document.removeEventListener('visibilitychange', this.onVisibilityChange)
        this.themeObserver?.disconnect()
        this.container.removeEventListener('click', this.onContainerClick)
        this.container.removeEventListener('wheel', this.onWheel)
        const { view, book } = this
        this.view = null
        this.book = null
        this.file = null
        const free = () => {
            try { book?.destroy?.() } catch { /* nothing to free */ }
        }
        // (after a view being replaced, if any, has gone too)
        if (view) this.retireView(view, () => nextFrames().then(free))
        else free()
    }
}

// Open a book in `container` (an empty element that has its final size).
// opts: { url, name, path, size, settings (object or JSON), layout ({continuous, twoPages,
//   cover} or JSON), positionsKey, saved?, onEvent(type, detail) }
// Events: relocate {fraction, tocId, tocLabel, pageLabel, atStart, atEnd}, middle (a tap in
// the middle), turn {side}, footnote {text, href}, external {href}, readerror {code}.
// Resolves with { title, dir, fixedLayout, language, toc, location }; rejects with an
// Error whose `code` is PROTECTED, KFX, DAMAGED or NETWORK (CLOSED when closed meanwhile).
export const openBook = async (container, opts) => {
    current?.close()
    const session = new Session(container, opts ?? {})
    current = session
    try {
        return await session.open()
    } catch (e) {
        const closed = session.closed
        session.close()
        if (current === session) current = null
        if (closed) throw new ReaderError('CLOSED', 'Closed')
        if (e instanceof ReaderError) {
            if (e.code === DAMAGED && session.networkFailed) throw new ReaderError(NETWORK, e.message)
            throw e
        }
        console.warn(e)
        throw new ReaderError(session.networkFailed ? NETWORK : DAMAGED, String(e?.message ?? e))
    }
}

export const closeBook = () => {
    current?.close()
    current = null
}

// next / prev (arg: a distance in px when scrolling), left / right, start / end,
// fraction (0–1), href, settings / layout (an object or its JSON), focus, close
export const command = (name, arg) => {
    if (name === 'close') return closeBook()
    return current?.command(name, arg)
}
