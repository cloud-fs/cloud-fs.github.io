# foliate-js (vendored)

The web console's book reader (`../book-reader.js`) renders EPUB, MOBI, AZW, AZW3 and CBZ
with these files from foliate-js:

- **Upstream:** https://github.com/johnfactotum/foliate-js
- **Commit:** `78914aef4466eb960965702401634c2cb348e9b1` (2026-05-01)
- **License:** MIT, see `LICENSE` (Copyright (c) 2022 John Factotum)

The files are copied unchanged. Only what the reader loads is here: `view.js` and its imports
(`epubcfi.js`, `progress.js`, `overlayer.js`, `text-walker.js`), the book loaders (`epub.js`,
`mobi.js`, `comic-book.js`), the renderers (`paginator.js`, `fixed-layout.js`) and two bundled
libraries in `vendor/`:

- `vendor/zip.js`: [zip.js](https://github.com/gildas-lormeau/zip.js) by Gildas Lormeau,
  BSD-3-Clause, bundled by foliate-js's rollup build;
- `vendor/fflate.js`: [fflate](https://github.com/101arrowz/fflate) by Arjun Barrett, MIT.

Left out on purpose: `pdf.js` and `vendor/pdfjs/` (PDF opens in the browser's own viewer),
`fb2.js` (FB2 comes later), `search.js`, `tts.js`, `footnotes.js` (the reader has its own
footnote popup), `dict.js`, `opds.js`, `ui/` and the demo `reader.html`/`reader.js`. `view.js`
imports some of them dynamically, but only on paths the reader never takes: it builds the
book itself and hands `view.open()` a book object, never a file.

To update: copy the same files from a newer commit, update the commit above, then open an
EPUB, an AZW3 and a CBZ in the console.
