
let loading = null
let reader = null
const load = () => {
    loading ??= import('/public/reader/book-reader.js')
        .then(m => (reader = m))
        .catch(e => {
            loading = null
            const error = new Error('The reader could not be loaded', { cause: e })
            error.code = 'NETWORK'
            throw error
        })
    return loading
}
export async function book_reader_open(container, opts) {
    const m = await load()
    return m.openBook(container, opts)
}
export function book_reader_command(name, arg) {
    try {
        const result = reader?.command(name, arg)
        if (typeof result?.catch === 'function') result.catch(e => console.warn(e))
    } catch (e) {
        console.warn(e)
    }
}
export function book_reader_error_code(e) {
    return typeof e?.code === 'string' ? e.code : ''
}
