﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-rcIWTVNnYus6VWf2Z2U1g\/JzlC07Ym02cFjHtI59Xsc=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-GhUDBeylTPHdJKKlfWVTLPy0keFtUZvPAYva+5GOiD4=",
      "url": "_framework\/dotnet.js"
    },
    {
      "hash": "sha256-LjLDIz9+J7uuiwMlQ4HbNx2BnSpphOtO2MwkoI28vdI=",
      "url": "_framework\/dotnet.native.8.0.0.vxbjjq8o6e.js"
    },
    {
      "hash": "sha256-Vr6ZXKoP77zgabrMIxQ1GbOkrxfx5XGqHO0odLhUIMY=",
      "url": "_framework\/dotnet.native.wasm"
    },
    {
      "hash": "sha256-WdSX3HQvnBYF0KJLZoOyHvTzMHetaob6PV0Kn2K+QXw=",
      "url": "_framework\/dotnet.runtime.8.0.0.xcaskdr5pq.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37\/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-Q57pG5Mwf6S6xGhc659\/GRXIzFZyVQB+uUL3srfpFPQ=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-sVDV8TMr7uuN09gMVgL0EI6sD0lskZoV5RH1ahbUQXU=",
      "url": "_framework\/BencodeNET.wasm"
    },
    {
      "hash": "sha256-xHBGFCMjDjvvTwtMvgaMBNmQk9JdVhGmws2\/GMZlxrI=",
      "url": "_framework\/Blazored.LocalStorage.wasm"
    },
    {
      "hash": "sha256-i2cBHftnHosZZLiNzjbDmWZEVt+U8D3Y1wqzUNX57b8=",
      "url": "_framework\/Blazored.Modal.wasm"
    },
    {
      "hash": "sha256-aKKBPt8newvFfXv9fzwxZgFqLOilz9B1W+naCRHpJG8=",
      "url": "_framework\/BlazorPagination.wasm"
    },
    {
      "hash": "sha256-PZQjafWAluqUbACOK3wBOFG+K6e5QeRhHI97RZHzaWI=",
      "url": "_framework\/CloudDriveWasm.wasm"
    },
    {
      "hash": "sha256-5PqRFSUCgfaYbutecSZ+it2\/0dGnVBpcd05A72M5jbk=",
      "url": "_framework\/Google.Protobuf.wasm"
    },
    {
      "hash": "sha256-Wl0oAxFk+8eE0ozQWPMhIEckIHdez+5EX4kz+yliOG8=",
      "url": "_framework\/Grpc.Core.Api.wasm"
    },
    {
      "hash": "sha256-fqiDc654YbJkdLcAPkPhIitrLMeENAQUMLjGf9US8NQ=",
      "url": "_framework\/Grpc.Net.Client.wasm"
    },
    {
      "hash": "sha256-0VFKBiudsKkc3vhVqE\/7xkHctNGLeFKkvxiqlxhnpO8=",
      "url": "_framework\/Grpc.Net.Client.Web.wasm"
    },
    {
      "hash": "sha256-spbiG4sFkjyZsWS3XLBxls2\/8HLGl9Og8SjbvptBdOA=",
      "url": "_framework\/Grpc.Net.Common.wasm"
    },
    {
      "hash": "sha256-PiFm\/DM104e9g0JN2PnU9rIsN8f1mqTHhcvRNH8dcVU=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Forms.wasm"
    },
    {
      "hash": "sha256-AWgKUnj21DcVkZSqBy81Mv1Yfy9d59DI4mpQaIYalhw=",
      "url": "_framework\/Microsoft.AspNetCore.Components.wasm"
    },
    {
      "hash": "sha256-N6AW51B+ZsaJZVdrCrdu2KGRWQKinmyX7Ds\/jd1E9V0=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.wasm"
    },
    {
      "hash": "sha256-elwAae7LAjEwukdOGO2Blcfs4U0aapAZxUFs2E3Y7CI=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.wasm"
    },
    {
      "hash": "sha256-uV6JPE8pFJZ3vgxDKUeimvMSk+wGuYyOKWg5xKqP7Qo=",
      "url": "_framework\/Microsoft.Bcl.AsyncInterfaces.wasm"
    },
    {
      "hash": "sha256-cBeu2DFe+O6ZtH6l\/qhTr9n2fc2flicfQtGa0kA1UQw=",
      "url": "_framework\/Microsoft.Bcl.HashCode.wasm"
    },
    {
      "hash": "sha256-S\/D1xFlojhkNTUwi8OprihMyWmboG8X1mCh2d48QT60=",
      "url": "_framework\/Microsoft.EntityFrameworkCore.Abstractions.wasm"
    },
    {
      "hash": "sha256-ubcnCSIDAicpAeB+2smphBmcPuMeQ0VTGoc5AqyS5WU=",
      "url": "_framework\/Microsoft.EntityFrameworkCore.wasm"
    },
    {
      "hash": "sha256-4wXvbgFkC3YVY7bc452wexdNETDO2oWLHHiA+uWaNJs=",
      "url": "_framework\/Microsoft.Extensions.Caching.Abstractions.wasm"
    },
    {
      "hash": "sha256-dlfc0lxjlnsCEY7w8NJ3BJOYCyf+zuOqOC60DHgBpRQ=",
      "url": "_framework\/Microsoft.Extensions.Caching.Memory.wasm"
    },
    {
      "hash": "sha256-87sn2TYqgdZ95sXmavjKEzoEfMgHnYQ9LOvnMX+aZcI=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.wasm"
    },
    {
      "hash": "sha256-Sxmy2ZS134URxbHEvdbS6NcQ3zXS7UWx\/5ZPpwiW7FA=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.wasm"
    },
    {
      "hash": "sha256-jYqHUZ07UYWc8POk7xhas6xQYH7t1qoTcylqoDqncJk=",
      "url": "_framework\/Microsoft.Extensions.Configuration.wasm"
    },
    {
      "hash": "sha256-HyhUBsdVoCKtLwM\/lDI1fngtTgjn1YNL6zE0CckzmXg=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.wasm"
    },
    {
      "hash": "sha256-qJwxB5CwRD4Y2\/b7PEdJ425+KDy0Pr2lBMeYLClJFtQ=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.wasm"
    },
    {
      "hash": "sha256-hc4v4EO6gEL92g8MBOTvZGE+9VDrUsjRzdJFxQGyBIg=",
      "url": "_framework\/Microsoft.Extensions.Localization.Abstractions.wasm"
    },
    {
      "hash": "sha256-WY8wzDYpbOl8wspMlvRknbN\/lqHg9753iaOQ7V6946A=",
      "url": "_framework\/Microsoft.Extensions.Localization.wasm"
    },
    {
      "hash": "sha256-r07xYtPxY+IIuCplLevYi7Qk8xgif8AJz3tS9pzg0GI=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.wasm"
    },
    {
      "hash": "sha256-XUo4EfkE0XrYcAKr6lMLVGyJ9Qf9M6xuLnGvJiCj13Q=",
      "url": "_framework\/Microsoft.Extensions.Logging.wasm"
    },
    {
      "hash": "sha256-daj5vN1mFtjFFrz6DxZyOFiUcuEsE8vIFC4JO8x0Rhs=",
      "url": "_framework\/Microsoft.Extensions.Options.wasm"
    },
    {
      "hash": "sha256-Ms2HR5Gpug\/0uRAzdk4SUNT76Ml3CjFv9Jo+dUIMGac=",
      "url": "_framework\/Microsoft.Extensions.Primitives.wasm"
    },
    {
      "hash": "sha256-dwgY2jxgSK996VBE1RZzn5SuX6xT\/WVJsLXCzkeBG8c=",
      "url": "_framework\/Microsoft.JSInterop.wasm"
    },
    {
      "hash": "sha256-CQVLCKiSxLN5ghyJZG3mhnMGRROdqrbNUjtAXB0nWb8=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.wasm"
    },
    {
      "hash": "sha256-oRXUy3wtv4ai64LPkN\/Q8oOtPrJ5P40\/RQL\/161yT74=",
      "url": "_framework\/netstandard.wasm"
    },
    {
      "hash": "sha256-IOILo\/zWNeOozKSxrRv0uLIVEZuGCN1Imq9QV3RfWmo=",
      "url": "_framework\/System.Collections.Concurrent.wasm"
    },
    {
      "hash": "sha256-UedkUI82kG1+XK3POKdbILwlyLSLoQ5DL0c8GxHiN\/I=",
      "url": "_framework\/System.Collections.Immutable.wasm"
    },
    {
      "hash": "sha256-JKQzRL0f\/YlHoCv3Aac53\/GgkSiOIF2T\/YESK4OGBKQ=",
      "url": "_framework\/System.Collections.NonGeneric.wasm"
    },
    {
      "hash": "sha256-ykxwFnC0Sgq90GQElMKE5\/Y0ebCGDoeRg5ni3FMVGWE=",
      "url": "_framework\/System.Collections.Specialized.wasm"
    },
    {
      "hash": "sha256-m5Dodx3lMKZqUGINA94jlV0V04lpIUQ0xPyJXMm0pig=",
      "url": "_framework\/System.Collections.wasm"
    },
    {
      "hash": "sha256-IpO+smGzhQZxLlo7iEs5O0Yl7BZm4vqjxPyJkmjoS1o=",
      "url": "_framework\/System.ComponentModel.Annotations.wasm"
    },
    {
      "hash": "sha256-QUp7uFKZ8ePNpxZUVqBIML0JFnbFwR+J\/nTjD8d7b68=",
      "url": "_framework\/System.ComponentModel.Primitives.wasm"
    },
    {
      "hash": "sha256-fK6mrDgkCWLT7pbrl5FC8BPr9FQv2U8jkKa44HeUrac=",
      "url": "_framework\/System.ComponentModel.TypeConverter.wasm"
    },
    {
      "hash": "sha256-GL0aENOaH6swLwwacgwyBPbF6V3B00VM2VPVaF05i0E=",
      "url": "_framework\/System.ComponentModel.wasm"
    },
    {
      "hash": "sha256-agFw1B0BO9gb8KmuTDcAjXnIdUmh3MV\/N7mDSrPYwsg=",
      "url": "_framework\/System.Console.wasm"
    },
    {
      "hash": "sha256-Knfv5wD0NpseViHRHeLAztDDNKlnX0+7o+HrSAdzLzM=",
      "url": "_framework\/System.Diagnostics.Debug.wasm"
    },
    {
      "hash": "sha256-a1mqS0EHH1QHhOztnUeExq6XwKvtFyOY5hsRHHuhwsk=",
      "url": "_framework\/System.Diagnostics.DiagnosticSource.wasm"
    },
    {
      "hash": "sha256-PSVvL+I7S2G\/M4Z4VXwe3159m\/H82SoMU03P3QShKzQ=",
      "url": "_framework\/System.IO.Compression.wasm"
    },
    {
      "hash": "sha256-xrlir+dvHE6g3cPgq\/WzxiQtz3DrgA5bCZZPzABpqwA=",
      "url": "_framework\/System.IO.Pipelines.wasm"
    },
    {
      "hash": "sha256-Bv7V4D3TN+eIjz5KZt7Ht7ehBZUKlNbq8mPUBzDDAKM=",
      "url": "_framework\/System.Linq.Expressions.wasm"
    },
    {
      "hash": "sha256-uZNbSaI5izsy6WwigV2oMtP\/pJRKmZkgz9\/d5ANp2a0=",
      "url": "_framework\/System.Linq.Queryable.wasm"
    },
    {
      "hash": "sha256-yJAH2w4ZtADeBZA1OSslPfwaVfb0xjL7ZKAC2enGHYU=",
      "url": "_framework\/System.Linq.wasm"
    },
    {
      "hash": "sha256-UCowkmi\/q02xMO5BQTa71hz\/nOzOClj3Rttb8kXSUl8=",
      "url": "_framework\/System.Memory.wasm"
    },
    {
      "hash": "sha256-Kz+8ZQXNHP0QGwzH+VLE6PsUoGYCob\/iTDU7kOEPu5I=",
      "url": "_framework\/System.Net.Http.wasm"
    },
    {
      "hash": "sha256-yGQ6d80sc\/pm3qEuoTuDdhvVkyfkEyVxuyK1vuTLySo=",
      "url": "_framework\/System.Net.NameResolution.wasm"
    },
    {
      "hash": "sha256-v8xSxT3dS3VJjfDRxMF+xuh4XVLq45wu6reoSOexAQg=",
      "url": "_framework\/System.Net.Primitives.wasm"
    },
    {
      "hash": "sha256-MvD0XK0uBcv\/dTQ+yhUsJ6e4X41CQsn6UsOM4osGCpw=",
      "url": "_framework\/System.Net.Sockets.wasm"
    },
    {
      "hash": "sha256-5xbX2Aj9qb36G90UaUcSkGP+R5fgqGN\/qNYcKyCF\/2Y=",
      "url": "_framework\/System.ObjectModel.wasm"
    },
    {
      "hash": "sha256-hOPlM4LVWgKqbyjEelJE465qDolm55LlWEiEywxSLks=",
      "url": "_framework\/System.Private.CoreLib.wasm"
    },
    {
      "hash": "sha256-RwiN8BooVK6lja73IlpVPMkJLW8AB9xyIleJAPq5XJ8=",
      "url": "_framework\/System.Private.Uri.wasm"
    },
    {
      "hash": "sha256-3ub9MMu0qdg3dBPjwwuXsAypH83SSB56Ebj\/xJDE0CU=",
      "url": "_framework\/System.Resources.ResourceManager.wasm"
    },
    {
      "hash": "sha256-TAtIMM4NMjNrLChnEM9FoIlR3eVDVC5v\/KP+4FwGQxE=",
      "url": "_framework\/System.Runtime.InteropServices.JavaScript.wasm"
    },
    {
      "hash": "sha256-s9IFHjJPMelArANlsFOrYAddzAfkWbMFNJ2alqD0yL8=",
      "url": "_framework\/System.Runtime.Serialization.Primitives.wasm"
    },
    {
      "hash": "sha256-b0aNZQb7VigITg20sI7YZt1Lr++cvL8L4hX51GUmW6w=",
      "url": "_framework\/System.Runtime.wasm"
    },
    {
      "hash": "sha256-ft3KDGbehj1DPMZkTF+5QBSl5D2Z6Upl1JdhmKqDzDI=",
      "url": "_framework\/System.Security.Cryptography.Algorithms.wasm"
    },
    {
      "hash": "sha256-1m6rT8aSMqlpIZrYocVH6u09W6jlnGvN7YPPJhFMnJs=",
      "url": "_framework\/System.Security.Cryptography.Primitives.wasm"
    },
    {
      "hash": "sha256-vrgbmuLwyy3RjOeTH7K3hylTN7O3QGuIDmEkrxievhU=",
      "url": "_framework\/System.Security.Cryptography.wasm"
    },
    {
      "hash": "sha256-roAD9oxlySPskG\/f0YnoUDWlRpxhu89rnf8M89edL\/o=",
      "url": "_framework\/System.Text.Encodings.Web.wasm"
    },
    {
      "hash": "sha256-x5RiNwJJkiVFxBOkQwPvpPql5Bw+qR9c4joOxKtx5WE=",
      "url": "_framework\/System.Text.Json.wasm"
    },
    {
      "hash": "sha256-ITWndLGDh1nGG47VTBRWTU8ADbv8cZbeOdFbVU6eaWo=",
      "url": "_framework\/System.Text.RegularExpressions.wasm"
    },
    {
      "hash": "sha256-jaCpI4SkA2DycsvneXXGSvXL2vSHcB4pq2BViPZ9Tss=",
      "url": "_framework\/System.Threading.Tasks.Extensions.wasm"
    },
    {
      "hash": "sha256-aB7kBookeCVBtzYATufS+qj9IVO0PFezYsejrhPp9Nc=",
      "url": "_framework\/System.Threading.Tasks.wasm"
    },
    {
      "hash": "sha256-eNBF1NZQUbRQjxvGUcD6aar+fOV3ce7z5DfrjoUAP+k=",
      "url": "_framework\/System.Threading.ThreadPool.wasm"
    },
    {
      "hash": "sha256-qhlc8E4VB9NeqTs0Waw9wCyCyqkZeRKSqOnl5v3V7EY=",
      "url": "_framework\/System.Threading.wasm"
    },
    {
      "hash": "sha256-jernLhoQUiUiVNuFfKzz58Ftzo+fg+nfM1ygpQ22RQs=",
      "url": "_framework\/System.Transactions.Local.wasm"
    },
    {
      "hash": "sha256-42a4+5LjOVNJZ9qrtuq44hJuXPS03tHmXb7Kauk7pEg=",
      "url": "_framework\/System.wasm"
    },
    {
      "hash": "sha256-hTvlIzeMsDFDNzWX7qraTShNe5hpXdmFYMA8vjlrJQw=",
      "url": "_framework\/System.Web.HttpUtility.wasm"
    },
    {
      "hash": "sha256-v07uAE7ftCYluQyUi3CMLrK30XPiWRPGx9pJHjYn0RU=",
      "url": "_framework\/zh-CN\/CloudDriveWasm.resources.wasm"
    },
    {
      "hash": "sha256-CYv0nn7bT6MDNbxEKrjtSsyOxHXfHgcMuMjH3wjTdHE=",
      "url": "CloudDriveWasm.styles.css"
    },
    {
      "hash": "sha256-BzoYU0RNaG3BWjfvRCeSYIkJpSn7x918+5xVluw5Tkk=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-vov5lh0nJsKXUXcsEEmdiuUoOYuUaXx\/cSkuYjQT834=",
      "url": "css\/clouddrive.css"
    },
    {
      "hash": "sha256-HtsXJanqjKTc8vVQjO4YMhiqFoXkfBsjBWcX91T1jr8=",
      "url": "css\/font-awesome\/css\/all.min.css"
    },
    {
      "hash": "sha256-IMSli8nR1p6TXQbxUokjZGpxW+XiGGZWVcrej18bjAA=",
      "url": "css\/font-awesome\/webfonts\/fa-brands-400.ttf"
    },
    {
      "hash": "sha256-dIMyCQxLjiD5XQ\/1nwviD6nIiTWdOzbUuIbXM3YFQgc=",
      "url": "css\/font-awesome\/webfonts\/fa-brands-400.woff2"
    },
    {
      "hash": "sha256-Uo0CLc5nJfiggR\/ZHY5lE0Rcge8zNTpcMjTquTJVGr8=",
      "url": "css\/font-awesome\/webfonts\/fa-regular-400.ttf"
    },
    {
      "hash": "sha256-jn5eobFfYqsU29QXaOj7zSHMhZpOpdqBJFfucUKZ+zU=",
      "url": "css\/font-awesome\/webfonts\/fa-regular-400.woff2"
    },
    {
      "hash": "sha256-Z6ZXY8f4CQPYFgO765BJ\/CvyhQhHm4PtAR\/iTHH6lQo=",
      "url": "css\/font-awesome\/webfonts\/fa-solid-900.ttf"
    },
    {
      "hash": "sha256-cVKmkz7j1pDsKvPQnanXAXI9Fqo0EKbYDyj\/iGbzuIA=",
      "url": "css\/font-awesome\/webfonts\/fa-solid-900.woff2"
    },
    {
      "hash": "sha256-BRWkI\/gozk5qzPkqLqCwPRnTHMhtmvA3MpHh\/U2180g=",
      "url": "css\/font-awesome\/webfonts\/fa-v4compatibility.ttf"
    },
    {
      "hash": "sha256-aUoXw9nWwF+KrGPFRGFVUqSyIOmk3oY9hzQaa8\/BvI0=",
      "url": "css\/font-awesome\/webfonts\/fa-v4compatibility.woff2"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Hb8l6pO6k0G4MSYUBex02eA87w0rPZo6Tr\/9LAQvdc8=",
      "url": "css\/site.css"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-6Y8OmaO6eOZHcnNmrlCpuqdlHZ3ox9GaP8S4ro0pLSE=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-B\/IsuMenTwjYCk3iwBfb7lDueRqR2AL2fuwAh6aZ9H0=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-bT6TZyGPe24VIQl+ggCXr71Vu6W0O7NqMwPTWZXtnyM=",
      "url": "img\/alipay-58x168.png"
    },
    {
      "hash": "sha256-OmSJsyJYmNdpXXX4UwwkR0TeIiktmb1kox2Lf3MOJis=",
      "url": "img\/ali-promo-qrcode.png"
    },
    {
      "hash": "sha256-2bLbQ2v16edVbuqX7INqZoiS+WF0goNLR6o1j6OGAhw=",
      "url": "img\/audio.png"
    },
    {
      "hash": "sha256-lwqpA1Ni8wD6H9cROreHKP8Av+YKmLZvvfUFSaAf7NA=",
      "url": "img\/cloud115.png"
    },
    {
      "hash": "sha256-Vp47sdviEWxOfg60NkKPqaBuxJu8RkTOr59XYgJ1K78=",
      "url": "img\/cloud189.png"
    },
    {
      "hash": "sha256-OT2HOaBn\/gfYu0UBwPX3S76H1+O+qNEH7pkP5lE+kKw=",
      "url": "img\/cloudaliyundrive.png"
    },
    {
      "hash": "sha256-r26AVwzRRVsB3exoeOUaF9enDI5ugT2JmzhN+mOsyCY=",
      "url": "img\/cloudbaidu.png"
    },
    {
      "hash": "sha256-5+BZIm1vG4MSFl\/Lg9P1QqvGHu\/kpJV4PRHTC9VhyV4=",
      "url": "img\/clouddrive-h.png"
    },
    {
      "hash": "sha256-EdM2ThRqF87ddManbXDwszsddKkTZSXgQthtU6zFaRg=",
      "url": "img\/cloudgoogledrive.png"
    },
    {
      "hash": "sha256-YYmYaBVcvVlWLE7+sTbuZg109B21B61ITnsA4UsJCvw=",
      "url": "img\/cloudgoogledrive_256.png"
    },
    {
      "hash": "sha256-j66dGEpFOsJIpsHqs0YdBfsUVC2gnlzQVcrRarrK5bk=",
      "url": "img\/cloudgoogledrive_okd.png"
    },
    {
      "hash": "sha256-jHtf4JG1KNJRwaA2nxsPQsMks+D\/5cVT7dfMTvANWGE=",
      "url": "img\/cloudhecaiyun.png"
    },
    {
      "hash": "sha256-ynL5CapzpkUd6ZoZOiO22C41aj6x\/3vn37aFEBChKaU=",
      "url": "img\/cloudonedrive_new.png"
    },
    {
      "hash": "sha256-jwfrMWl\/VtM5wuy95HRCs95kBS0FfSP937tlCgDF75o=",
      "url": "img\/cloudwocloud.png"
    },
    {
      "hash": "sha256-8uec+eiyKAyxTkS7ru8WZcBO\/xwCRBeSFiKdNrXMJLE=",
      "url": "img\/favicon.ico"
    },
    {
      "hash": "sha256-Oht9zxupxAhKKrjGeoDOvc8vLUPrxkPfCDMCwUxiaKk=",
      "url": "img\/file.png"
    },
    {
      "hash": "sha256-lmMg7NBojwTaPSWZcQwL\/UWx6meR\/\/GlIAFsD7uII+U=",
      "url": "img\/file32.png"
    },
    {
      "hash": "sha256-7HwAVRSjOjJle9N2wKz5fbTdq1XrrYjXL6riAMwHkTA=",
      "url": "img\/folder.png"
    },
    {
      "hash": "sha256-x1zai+wOZwsUQ72UwyKDJvN1C95sYOZ9PCO4CS5iRak=",
      "url": "img\/folder-00.png"
    },
    {
      "hash": "sha256-xWk78qkIlQdp376KmZMNaWLBtTWa0FoDu6ukCVH12P0=",
      "url": "img\/folder-00-32.png"
    },
    {
      "hash": "sha256-FgEVgt7hn7P++3MQBIafOhIkjMgLPbcfS1TVq+XbaQ8=",
      "url": "img\/folder32.png"
    },
    {
      "hash": "sha256-TJxqSEjU3XFNEivbJOYg6klzhiAWUDfoCt9bkWapvSA=",
      "url": "img\/iina.png"
    },
    {
      "hash": "sha256-pJkL19uwgNsypgcWttmAgpFJeHIjFtXfAutXHmalRlc=",
      "url": "img\/infuse.png"
    },
    {
      "hash": "sha256-umf1y7JtHJE1J0dYFfDI1MRRmwkqdUTwFcwCE2AkAnU=",
      "url": "img\/loading.gif"
    },
    {
      "hash": "sha256-+cyrdCODfyoxejv42wF5VZlFGpJEtxaYtmp2VGE62Qs=",
      "url": "img\/mpvplay.png"
    },
    {
      "hash": "sha256-LnduP5M\/5MFXDmcIj7fNotbPTJ\/mVidBeIuyfsZ5UNU=",
      "url": "img\/nplayer.png"
    },
    {
      "hash": "sha256-fCXhMuKybiFMOItLofX9E61+32a+hEvyLzlHxJjaiAo=",
      "url": "img\/photo.png"
    },
    {
      "hash": "sha256-dWfR+uMdsNrC5fS40hwk4q+YNsE0R90xwyXt0vwEtH4=",
      "url": "img\/photo32.png"
    },
    {
      "hash": "sha256-XsTKA5yeqAN\/YDf87HAKNAdGY\/zL91\/qyDQQcW9gaNU=",
      "url": "img\/pikpak.png"
    },
    {
      "hash": "sha256-Eab6H1L7l5DUQ4vLz7YN\/sAcVCbBRt2WID3kJI5c5Zg=",
      "url": "img\/potplayer.png"
    },
    {
      "hash": "sha256-VxzaDLkxLmJPa\/1gDhpLmQ5Tmei2H44842LKgBGP5pw=",
      "url": "img\/video.png"
    },
    {
      "hash": "sha256-QOqxebWp1vtuhfBfIM63YR+thJ+nlSzIkYaruVMtss4=",
      "url": "img\/video32.png"
    },
    {
      "hash": "sha256-R83jlmOcwrsTitXIRX9JmtMDX3e9mDNXQACBZ7TkHeM=",
      "url": "img\/vlc.png"
    },
    {
      "hash": "sha256-f0FwWcTykJF6kq+Y1qTIZLrC2g82PtrGD5kUGOM3ZQE=",
      "url": "img\/webdav.png"
    },
    {
      "hash": "sha256-ErQ8HjZorJa9IVA8iiQBXIs9NO\/A4NbzEzDTjlVyu8c=",
      "url": "index.html"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "js\/clouddrive.js"
    },
    {
      "hash": "sha256-hhkOXovn+\/waq\/Ptu3z3wDZjYcNebzJjMMp0oZFNEvc=",
      "url": "js\/hammer.min.js"
    },
    {
      "hash": "sha256-UENMN4e\/V1APGDuqEXPdeaOBoZag97G+DGWcOVhYaZk=",
      "url": "js\/html5-qrcode.js"
    },
    {
      "hash": "sha256-XSMtlAMe0+Vbo\/xmX8BX8a3TPQWLLlmn68LrJ3cFN94=",
      "url": "js\/myjs.js"
    },
    {
      "hash": "sha256-KoW8MYYQlEnUiICw7niXXl7OV6wfeHl2DZG43FtQWtg=",
      "url": "js\/myphotoswipe.js"
    },
    {
      "hash": "sha256-QlKuNLQZGB3vyS5WyYm5v84JjpwSdHYGQBtxfcrbGzY=",
      "url": "js\/qrcode.js"
    },
    {
      "hash": "sha256-RhHKfxJHXe1kM\/cIU+riLcEl\/qLmaKHt+\/upLTzCer0=",
      "url": "js\/split.min.js"
    },
    {
      "hash": "sha256-MAap2qDbM+MBXc9wjksPXHIHGSdZCj15syKJ+Qc9JbE=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yGxgE2UZtSaTBTg1y1YbmZA0+dBpWxs+vUxsWH8Otlg=",
      "url": "photoswipe\/default-skin\/default-skin.css"
    },
    {
      "hash": "sha256-GgmX8Iv9eo6fEH+SpQNacvAFoZ0BZqVjIIKoLP98SEU=",
      "url": "photoswipe\/default-skin\/default-skin.css.map"
    },
    {
      "hash": "sha256-mIh\/w5EQ1yETyYDl2PSEWnxmrCic+enxYNIEtc4tkys=",
      "url": "photoswipe\/default-skin\/default-skin.png"
    },
    {
      "hash": "sha256-sQn9iBHWJYS7POpG0\/mI0CmpV0wLjjYQmWDyhd62Kws=",
      "url": "photoswipe\/default-skin\/default-skin.svg"
    },
    {
      "hash": "sha256-gNftPz9LUGKPIZd424FJVefSAHwFvohVZ3j5DuKQcVw=",
      "url": "photoswipe\/default-skin\/preloader.gif"
    },
    {
      "hash": "sha256-FQhiXWr9\/O0bAts0Bg7axhsFE\/OEiBqaHYoh7c0MaWU=",
      "url": "photoswipe\/photoswipe.css"
    },
    {
      "hash": "sha256-SGrWcmZiQ6hgRCjHN6Tu+YZPH\/IHY4pXGFNOmKP3BWA=",
      "url": "photoswipe\/photoswipe.css.map"
    },
    {
      "hash": "sha256-HAeC4wGSJkSzyQl4hUClccYPjM4MvgrFi7j\/PaFP4kE=",
      "url": "photoswipe\/photoswipe.js"
    },
    {
      "hash": "sha256-csLEQWl2e5M6lADp3lAOAd31hEdNdVy4URsuk6OLaqY=",
      "url": "photoswipe\/photoswipe.min.js"
    },
    {
      "hash": "sha256-FEMe4fGPe7\/sjSaaW4Tk3Cy3+UM6hQCG\/zMcBqJSJTY=",
      "url": "photoswipe\/photoswipe-ui-default.js"
    },
    {
      "hash": "sha256-31SqlpZuZG1WK\/TE+Vbmo\/zpveXl5RbYYSeUl3gOfxg=",
      "url": "photoswipe\/photoswipe-ui-default.min.js"
    },
    {
      "hash": "sha256-UcVCXWmgp9LvKXOR4Iyu3UCqBbCwM7fNaTwQL78vd88=",
      "url": "sw-registrator.js"
    },
    {
      "hash": "sha256-NRzGRdnlAxAGthP9SY4CJqDqVewUV+0ZXzfRxXher1I=",
      "url": "_content\/Blazored.Modal\/Blazored.Modal.bundle.scp.css"
    },
    {
      "hash": "sha256-JnMrV9FYOYSibA85LvQGGV3uJ7zv2njdJX1GFslt2Aw=",
      "url": "_content\/Blazored.Modal\/BlazoredModal.razor.js"
    }
  ],
  "version": "7MobV88t"
};
