﻿export function setBodyStyle() {
    document.body.style.overflow = 'hidden';
}

export function removeBodyStyle() {
    document.body.style.overflow = 'auto';
}