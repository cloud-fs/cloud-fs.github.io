// The media client's in-browser playback (MEDIA_SERVER.md §9, step 2). Loaded only when a title needs it.
//
// - `CdMedia.Decoder`: files the browser's own <video> can't play, demuxed and decoded here with libmedia's AVPlayer
//   (MSE where the browser takes the codecs, else WebCodecs for video and FFmpeg decoders in WebAssembly for AC-3,
//   E-AC-3, DTS, MPEG-2, MPEG-4 Part 2 and the rest). Threads when the page is cross-origin isolated, else workers.
// - `CdMedia.Subtitles`: ASS/SSA drawn by JASSUB (libass), PGS by libpgs, over a <video> or the decoder's picture.
//   PGS inside a file the decoder plays: libmedia demuxes it but draws only text, so its packets are taken from
//   libmedia's subtitle path as they're read (`PgsFeed`) and handed to libpgs as .sup bytes.
//
// The libraries are files beside this one (public/media/), loaded on first use: a NAS may have no internet.
(function () {
  'use strict';
  const here = (document.currentScript && document.currentScript.src) || location.origin + '/public/media/cd-player.js';
  const BASE = here.slice(0, here.lastIndexOf('/'));

  const loaded = {};
  function script(src) {
    if (!loaded[src]) {
      loaded[src] = new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = src;
        s.async = true;
        s.onload = () => resolve();
        s.onerror = () => { delete loaded[src]; reject(new Error('could not load ' + src)); };
        document.head.appendChild(s);
      });
    }
    return loaded[src];
  }

  // WebAssembly SIMD: the vendored decoders are the SIMD builds.
  let simd = null;
  function hasSimd() {
    if (simd === null) {
      try {
        simd = WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 5, 1, 96, 0, 1, 123, 3, 2, 1, 0,
          10, 10, 1, 8, 0, 65, 0, 253, 15, 253, 98, 11]));
      } catch (e) {
        simd = false;
      }
    }
    return simd;
  }

  /** Whether this browser can run the decoder at all. */
  function supported() {
    return typeof WebAssembly === 'object' && hasSimd() && typeof Worker === 'function' &&
      typeof (window.AudioContext || window.webkitAudioContext) === 'function';
  }

  /** Threads (SharedArrayBuffer) are there only when the page is cross-origin isolated (COOP/COEP). */
  function threads() {
    return !!window.crossOriginIsolated && typeof SharedArrayBuffer === 'function';
  }

  // libmedia's codec ids (FFmpeg's AVCodecID) → the decoder file vendored for it.
  const DECODERS = {
    2: 'mpeg2video', 12: 'mpeg4', 27: 'h264', 173: 'hevc', 167: 'vp9', 225: 'av1',
    86017: 'mp3', 86018: 'aac', 86019: 'ac3', 86020: 'dca', 86021: 'vorbis', 86028: 'flac', 86056: 'eac3',
    86076: 'opus',
    // ours, not libmedia's: FFmpeg's TrueHD and MLP decoders (THIRD_PARTY.txt)
    86045: 'truehd', 86060: 'truehd',
  };
  const OWN_DECODERS = [86045, 86060];
  function wasmFor(type, codecId) {
    const lib = BASE + '/libmedia';
    if (type === 'resampler') return lib + '/resample/resample-simd.wasm';
    if (type === 'stretchpitcher') return lib + '/stretchpitch/stretchpitch-simd.wasm';
    if (type !== 'decoder') return null;
    if (codecId > 65536 && codecId <= 65572) return lib + '/decode/pcm-simd.wasm';
    const name = DECODERS[codecId];
    return name ? lib + '/decode/' + name + '-simd.wasm' : null;
  }

  // The codec names the server's MediaStreams use, for the decoders vendored here.
  const AUDIO_DECODED = ['aac', 'ac3', 'eac3', 'dts', 'dca', 'mp3', 'flac', 'opus', 'vorbis', 'mp2', 'pcm', 'truehd',
    'mlp'];
  const VIDEO_DECODED = ['h264', 'avc', 'hevc', 'h265', 'mpeg2video', 'mpeg2', 'mpeg4', 'xvid', 'divx', 'vp9', 'av1',
    'vp8'];
  /** Whether the decoder takes a stream of `codec` (a server codec name) of `type` ('Audio' or 'Video'). */
  function decodes(type, codec) {
    const c = String(codec || '').toLowerCase();
    if (!c) return true;
    if (type === 'Audio') return AUDIO_DECODED.includes(c) || c.startsWith('pcm');
    if (type === 'Video') return VIDEO_DECODED.includes(c);
    return true;
  }

  /** A stream's PID in a TS, as the reader names it (`metadata.cdpid`, THIRD_PARTY.txt); 0 when not known. */
  function pidOf(s) {
    return +((s && s.metadata && s.metadata.cdpid) || (s && s.pid) || 0);
  }

  /** The stream at `order` of one kind's streams `list`: the one of the PID `pids` names for it, if it names one. */
  function atOrder(list, order, pids) {
    const pid = pids && order >= 0 ? pids[order] : 0;
    return pid ? list.find((s) => pidOf(s) === pid) : list[order];
  }

  /**
   * How a Dolby Vision picture (`dv`: profile, level, compat) goes to the browser's own player (MSE) where that plays
   * Dolby Vision (Safari): profile 5 as `dvh1` with its `dvcC` (as plain HEVC its colours are wrong), profile 8 with
   * its `dvvC` beside `hvc1`. Null elsewhere: Chrome's MSE turns down a profile 5 or 7 stream carrying one, and plays
   * profile 8's HDR10 without; Safari won't decode profile 7 with one, and plays its HDR10 base without.
   */
  function dvPlan(dv) {
    const MS = window.ManagedMediaSource || window.MediaSource;
    const p = dv && dv.profile;
    if ((p !== 5 && p !== 8) || !MS || !MS.isTypeSupported(`video/mp4; codecs="dvh1.0${p}.06"`)) return null;
    // DOVIDecoderConfigurationRecord: version 1.0; profile, level, RPU, no EL, BL; compatibility; the rest reserved
    const b = new Uint8Array(32);
    const v = new DataView(b.buffer);
    v.setUint32(0, 32);
    b.set([...(p > 7 ? 'dvvC' : 'dvcC')].map((c) => c.charCodeAt(0)), 4);
    b[8] = 1;
    v.setUint16(10, (p << 9) | (Math.min(dv.level || 6, 63) << 3) | 0b101);
    b[12] = (p === 8 ? (dv.compat || 1) & 15 : 0) << 4;
    return { box: [...b].map((x) => x.toString(16).padStart(2, '0')).join(''), tag: p === 5 ? 'dvh1' : '' };
  }

  /**
   * Whether a profile 5 picture the browser shows no Dolby Vision for (Chrome, Edge) is decoded here instead: libmedia's
   * own decoder hands each frame its RPU, which its WebGPU renderer reshapes with (patch_libmedia.py). It needs threads
   * and a WebGPU adapter (else libmedia draws with WebGL, which doesn't reshape).
   */
  let gpuAdapter = null;
  async function softDvPlan(dv) {
    if (!dv || dv.profile !== 5 || !threads() || !navigator.gpu) return false;
    if (gpuAdapter === null) {
      try {
        gpuAdapter = !!(await navigator.gpu.requestAdapter());
      } catch (e) {
        gpuAdapter = false;
      }
    }
    return gpuAdapter;
  }

  /**
   * Why a profile 5 picture isn't decoded here where the browser shows no Dolby Vision (its colours then wrong):
   * 'insecure' (a page not on HTTPS has neither threads nor WebGPU), 'threads' (not cross-origin isolated), 'gpu' (no
   * WebGPU adapter).
   */
  function softDvMissing() {
    if (!window.isSecureContext) return 'insecure';
    if (!threads()) return 'threads';
    return 'gpu';
  }

  /** The events Safari counts as the user's own, in which it lets sound start. */
  const SOUND_GESTURES = ['click', 'keydown', 'touchend'];
  /** How long the time shows on a full screen copy after it goes there or plays (see mirrorVideo). */
  const INFO_MS = 4000;

  /** `s` seconds as 1:02:03 (or 2:03). */
  function clockText(s) {
    const n = Math.max(0, Math.floor(s));
    const hh = Math.floor(n / 3600);
    const mm = Math.floor(n / 60) % 60;
    const ss = String(n % 60).padStart(2, '0');
    return hh ? `${hh}:${String(mm).padStart(2, '0')}:${ss}` : `${mm}:${ss}`;
  }

  /** The file extensions libmedia's MP4 reader reads (see `readSubtitle`). */
  const MP4_READ = ['mp4', 'm4v', 'mov', '3gp'];

  /** The sound codecs the browser's player (MSE) may take in MP4, by libmedia's codec id. */
  const MSE_AUDIO = { 86018: 'mp4a.40.2', 86019: 'ac-3', 86056: 'ec-3', 86076: 'opus', 86028: 'flac' };
  function mseAudio(codecId) {
    const MS = window.ManagedMediaSource || window.MediaSource;
    const c = MSE_AUDIO[codecId];
    return !!(c && MS && MS.isTypeSupported(`audio/mp4; codecs="${c}"`));
  }
  /** The pictures the browser's player (MSE) may take in MP4, by libmedia's codec id (HEVC: see mseVideo). */
  const MSE_VIDEO = { 27: 'avc1.640033', 167: 'vp09.00.51.08', 225: 'av01.0.13M.10' };
  /** PQ and HLG, libmedia's (FFmpeg's) colour transfer of an HDR picture. */
  const HDR_TRC = [16, 18];
  function mseVideo(cp) {
    const MS = window.ManagedMediaSource || window.MediaSource;
    if (!MS || !cp) return false;
    const ten = cp.profile === 2 || HDR_TRC.includes(cp.colorTrc);
    const c = cp.codecId === 173 ? (ten ? 'hvc1.2.4.L153.B0' : 'hvc1.1.6.L153.B0') : MSE_VIDEO[cp.codecId];
    return !!(c && MS.isTypeSupported(`video/mp4; codecs="${c}"`));
  }
  /**
   * Whether a picture (its codecpar) would be decoded here with no hardware to do it, where the browser's player would
   * take it with a sound it plays: no WebCodecs (a page not on HTTPS, Safari's too), and HDR or bigger than 1080p, which
   * libmedia hands to that player only when it takes the sound as well (its checkUseMSE asks the sound first). A 4K
   * picture decoded here in WebAssembly can't keep up: a Blu-ray's DTS or TrueHD kept it there on an iPhone.
   */
  function pictureNeedsMse(cp) {
    if (typeof VideoDecoder === 'function' || !cp) return false;
    const big = (cp.width || 0) * (cp.height || 0) > 2073600;
    return (big || HDR_TRC.includes(cp.colorTrc)) && mseVideo(cp);
  }
  /**
   * Among the audio streams `info` (libmedia's, with codecparProxy), one the browser's player takes, in the language of
   * `pick` when that has one; not a commentary (FFmpeg's AV_DISPOSITION_COMMENT) where another will do.
   */
  function mseAudioFor(info, pick) {
    const lang = (s) => (s.metadata && (s.metadata.language || s.metadata.LANGUAGE)) || '';
    const ok = info.filter((s) => mseAudio(s.codecparProxy.codecId) && (!lang(pick) || lang(s) === lang(pick)));
    return ok.find((s) => !(s.disposition & 0x8)) || ok[0];
  }
  /**
   * Whether libmedia won't move the browser's player (MSE) from the sound `from` to `to` (codecparProxy each) as it
   * plays: in Safari it refuses one of another codec, sample rate, channel count or profile ("safari not support switch
   * stream in mse"), as a Blu-ray's AC-3 5.1 to its AC-3 stereo. Every iPhone and iPad browser is Safari's engine.
   */
  function mseSwitchRefused(from, to) {
    const ua = navigator.userAgent;
    if (!from || !to || !/AppleWebKit/.test(ua) || /Chrome\/|Chromium|Edg\//.test(ua)) return false;
    return from.codecId !== to.codecId || from.sampleRate !== to.sampleRate || from.profile !== to.profile ||
      from.chLayout.nbChannels !== to.chLayout.nbChannels;
  }

  /**
   * The picture among libmedia's video streams: the biggest (the default of those). A Blu-ray's Dolby Vision profile 7
   * carries its enhancement layer as a second, smaller HEVC stream, which libmedia lists first when its packets come
   * first; decoded alone it's a green screen.
   */
  function pictureOf(streams) {
    const area = (s) => (s.codecparProxy.width || 0) * (s.codecparProxy.height || 0);
    return streams.filter((s) => s.codecparProxy && s.codecparProxy.codecType === 0 && !(s.disposition & 0x400))
      .reduce((a, s) => (!a || area(s) > area(a) || (area(s) === area(a) && (s.disposition & 1) && !(a.disposition & 1))
        ? s : a), undefined);
  }

  function mediaTypeName(t) {
    return t === 0 ? 'Video' : t === 1 ? 'Audio' : t === 3 ? 'Subtitle' : 'Other';
  }

  // ------------------------------------------------------------------------------ PGS inside the file

  // libmedia's codec id for Blu-ray PGS (AV_CODEC_ID_HDMV_PGS_SUBTITLE), and the subtitle codecs it draws itself
  // (webvtt, subrip, ass, ssa, ttml, mov_text, text: AVPlayer's own list)
  const PGS = 94214;
  const TEXT_SUBS = [94226, 94225, 94230, 94212, 94232, 94213, 94210];
  const NOPTS = -(BigInt(1) << BigInt(63));

  // libmedia 1.3.1 (npm @libmedia/avplayer, dist/umd) as vendored: its webpack modules used here. 17630 (chunks 384
  // and 630): the SubtitleRender, which pulls the subtitle stream's packets from the demuxer as the file is read and
  // decodes text only; for PGS its pull is ours. 56238.f: the heap's readers (15 int32, 17 int64); 46564: iI a
  // packet's data, Qe frees one; 26669.r0: a packet sent as a copy made a packet again. Another build of the same
  // version must keep these, else PGS inside a file isn't shown (said so).
  const LIB = { render: 17630, chunks: [384, 630], heap: 56238, packet: 46564, copy: 26669 };
  // an AVPacket's fields (libmedia's struct): pts, the stream's index, the time base (num, den)
  const PKT = { pts: 8, stream: 32, tbNum: 72, tbDen: 76 };

  let subHook = null;
  /**
   * Mends libmedia's subtitles inside the file; resolves false if it can't (then PGS isn't shown).
   * - Without threads (a page not cross-origin isolated: `http://` on a LAN address) the demuxer's worker answers a
   *   subtitle pull with a copy of the packet, which the SubtitleRender reads as an address: no subtitle inside the
   *   file showed. The copy is made a packet again, as libmedia does for audio and video.
   * - PGS: the SubtitleRender's pull hands its packets to the decoder's `PgsFeed`.
   */
  function hookSubtitles() {
    if (!subHook) {
      subHook = (async () => {
        let req = null;
        const list = window.webpackChunkAVPlayer;
        // webpack runs a chunk's third member with its require; the chunk is ours, and empty
        if (list && typeof list.push === 'function') list.push([['cd-media-subtitles'], {}, (r) => { req = r; }]);
        if (!req || typeof req.e !== 'function') return false;
        await Promise.all(LIB.chunks.map((c) => req.e(c)));
        const Render = req(LIB.render).default;
        const heap = req(LIB.heap).f;
        const packet = req(LIB.packet);
        const copy = req(LIB.copy).r0;
        const proto = Render && Render.prototype;
        if (!proto || typeof proto.createDecoder !== 'function' || typeof proto.pull !== 'function' ||
          typeof proto.getDemuxerPort !== 'function' || !heap || typeof heap[15] !== 'function' ||
          typeof heap[17] !== 'function' || typeof packet.iI !== 'function' || typeof packet.Qe !== 'function' ||
          typeof copy !== 'function') {
          return false;
        }
        const port = proto.getDemuxerPort;
        proto.getDemuxerPort = function (task) {
          const out = port.call(this, task);
          const render = this;
          const ipc = this.leftPorts.get(task);
          if (ipc && !ipc.cdCopies) {
            ipc.cdCopies = true;
            const request = ipc.request;
            ipc.request = async function () {
              const p = await request.apply(this, arguments);
              if (!p || typeof p !== 'object' || !p.data) return p;
              // in the pool's packet, which the pull gives back to it
              return copy(p, render.avpacketPool ? render.avpacketPool.alloc() : 0);
            };
          }
          return out;
        };
        const lib = { heap, data: packet.iI, free: packet.Qe };
        const create = proto.createDecoder;
        proto.createDecoder = function () {
          create.call(this);
          this.pgs = !!this.decoder && !this.decoder.decoder && heap[15](this.options.codecpar + 4) === PGS;
          // libmedia has no decoder for it: one that takes nothing in its place, the packets being read in pull
          if (this.pgs) this.decoder.decoder = { sendAVPacket: () => 0, receiveAVFrame: () => 0, flush: () => 0 };
        };
        const pull = proto.pull;
        proto.pull = function () {
          return this.pgs ? pullPgs(this, lib) : pull.call(this);
        };
        return true;
      })().catch((e) => {
        console.warn('subtitles inside the file:', e);
        return false;
      });
    }
    return subHook;
  }

  // the open decoders, for a SubtitleRender to find its own
  const decoders = new Set();

  /**
   * The SubtitleRender's pull for PGS: the packets as the demuxer reads them, to the feed of the decoder whose
   * SubtitleRender it is, and back to libmedia.
   */
  async function pullPgs(render, lib) {
    if (render.pulling && !render.ended) return;
    render.pulling = true;
    // libmedia lets another pull start when it switches files (an external subtitle's): this one then ends
    const mine = render.pgsTurn = (render.pgsTurn || 0) + 1;
    try {
      // until it stops, is switched or the file ends; each answer waits for the demuxer to read one
      while (render.loop && render.loop.isStarted() && !render.ended && render.pgs && render.pgsTurn === mine) {
        const port = render.currentPort;
        const ipc = render.leftPorts.get(port);
        if (!ipc) break;
        const p = await ipc.request('pull');
        // a number below zero: the end of the file, or an error
        if (typeof p !== 'number' || p < 0) {
          render.ended = true;
          break;
        }
        const stream = lib.heap[15](p + PKT.stream);
        const pts = lib.heap[17](p + PKT.pts);
        const num = lib.heap[15](p + PKT.tbNum);
        const den = lib.heap[15](p + PKT.tbDen);
        // the packet goes back to libmedia: its bytes copied
        const bytes = lib.data(p).slice();
        if (render.avpacketPool) render.avpacketPool.release(p);
        else lib.free(p);
        if (!render.loop || port !== render.currentPort) continue;
        const owner = [...decoders].find((d) => d.player && d.player.subtitleRender === render);
        if (!owner || !owner.pgsFeed || owner.pgsFeedIndex !== stream) continue;
        // a packet left from the stream before is not this one's
        const s = (owner.player.formatContext && owner.player.formatContext.streams || [])
          .find((x) => x.codecpar === render.options.codecpar);
        if (!s || s.index !== stream) continue;
        owner.pgsFeed.packet(bytes, pts === NOPTS || !den ? -1 : Number(pts) * 1000 * num / den - owner.origin * 1000);
      }
    } catch (e) {
      console.warn('PGS pull', e);
    } finally {
      if (render.pgsTurn === mine) render.pulling = false;
    }
  }

  // PGS segment types: palette, object, presentation composition, window, end
  const SEGMENTS = [0x14, 0x15, 0x16, 0x17, 0x80];

  /**
   * The PGS display sets read so far, in time order, as .sup bytes ("PG", the 90 kHz PTS and DTS, then the segment)
   * for libpgs, which reads a whole .sup at a time: the page loads it the window from the composition the picture
   * needs on, as more is read (`buffer`). A seek starts it over (`clear`): libmedia reads again from there.
   */
  class PgsFeed {
    constructor() {
      this.sets = [];
      this.open = null;
      this.chain = Promise.resolve();
      this.turn = 0;
      this.onChange = null;
    }

    /** A packet's bytes (one or more segments) at `pts` ms, in the order read. */
    packet(bytes, pts) {
      const turn = this.turn;
      this.chain = this.chain.then(async () => {
        // mkvmerge's zlib, when libmedia leaves it on (ContentCompAlgo not written): a segment never starts so
        if (bytes.length > 2 && !SEGMENTS.includes(bytes[0]) && bytes[0] === 0x78 && typeof DecompressionStream === 'function') {
          bytes = await inflate(bytes);
        }
        if (turn === this.turn) this.take(bytes, pts);
      }).catch((e) => console.warn('PGS packet', e));
    }

    take(bytes, pts) {
      let changed = false;
      for (let i = 0; i + 3 <= bytes.length;) {
        const type = bytes[i];
        const end = i + 3 + ((bytes[i + 1] << 8) | bytes[i + 2]);
        if (end > bytes.length || !SEGMENTS.includes(type)) break;
        const seg = bytes.subarray(i, end);
        i = end;
        if (type === 0x16) {
          // a presentation composition begins a display set: its state, at payload byte 7 (0: a normal case, else
          // an epoch start or an acquisition point, which needs nothing before it)
          this.open = pts >= 0 && seg.length >= 11 ? { pts, state: seg[10], parts: [seg] } : null;
        } else if (this.open) {
          this.open.parts.push(seg);
          if (type === 0x80) {
            this.add(this.open);
            this.open = null;
            changed = true;
          }
        }
      }
      if (changed && this.onChange) this.onChange();
    }

    add(set) {
      const pts90 = Math.max(0, Math.min(LAST_PTS - 1, Math.round(set.pts * 90)));
      let size = 0;
      for (const p of set.parts) size += 10 + p.length;
      const out = new Uint8Array(size);
      const view = new DataView(out.buffer);
      let at = 0;
      for (const p of set.parts) {
        out[at] = 0x50;
        out[at + 1] = 0x47;
        view.setUint32(at + 2, pts90);
        out.set(p, at + 10);
        at += 10 + p.length;
      }
      const item = { pts: set.pts, state: set.state, bytes: out, pcs: set.parts[0] };
      // read again after a seek back: the same set replaced
      let i = this.sets.length;
      while (i > 0 && this.sets[i - 1].pts > set.pts) i--;
      if (i > 0 && this.sets[i - 1].pts === set.pts) this.sets[i - 1] = item;
      else this.sets.splice(i, 0, item);
    }

    /** The .sup bytes to show from `now` (ms) on: from the composition the set showing then starts from. */
    buffer(now) {
      let k = 0;
      while (k + 1 < this.sets.length && this.sets[k + 1].pts <= now) k++;
      while (k > 0 && this.sets[k].state === 0) k--;
      // what's before it is past
      if (k > 0) this.sets.splice(0, k);
      let size = 0;
      for (const s of this.sets) size += s.bytes.length;
      const last = this.sets[this.sets.length - 1];
      // libpgs shows nothing after its last set: an empty one far on keeps the last read shown till the next comes
      const tail = last ? endSet(last.pcs) : new Uint8Array(0);
      const out = new Uint8Array(size + tail.length);
      let at = 0;
      for (const s of this.sets) {
        out.set(s.bytes, at);
        at += s.bytes.length;
      }
      out.set(tail, at);
      return out;
    }

    clear() {
      this.turn++;
      this.sets = [];
      this.open = null;
      if (this.onChange) this.onChange();
    }
  }

  // libpgs reads a PTS as a signed number: the last it takes (6.6 hours)
  const LAST_PTS = 0x7fffffff;

  /** A display set showing nothing, at the last PTS libpgs can read, the size of `pcs`'s. */
  function endSet(pcs) {
    const out = new Uint8Array(13 + 11 + 13);
    const v = new DataView(out.buffer);
    out.set([0x50, 0x47], 0);
    v.setUint32(2, LAST_PTS);
    out.set([0x16, 0, 11], 10);
    // width, height; frame rate; composition 0, normal case, no palette update, palette 0, no objects
    out.set(pcs.subarray(3, 7), 13);
    out[17] = 0x10;
    out.set([0x50, 0x47], 24);
    v.setUint32(26, LAST_PTS);
    out[34] = 0x80;
    return out;
  }

  async function inflate(bytes) {
    const s = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate'));
    return new Uint8Array(await new Response(s).arrayBuffer());
  }

  /**
   * Plays `url` in `container` with libmedia. `opts`:
   * - ext: the file's extension (mkv, ts, avi…), as the link has none;
   * - audio: which audio stream, counted among the file's audio streams (0 = the first);
   * - subtitle: the subtitle inside the file to read from the start, counted among its subtitle streams (-1: none
   *   asked for); shown once `selectSubtitle` says so;
   * - audioPids, subtitlePids: in a TS (a Blu-ray's title), the PID of each audio and subtitle stream in the order
   *   they are counted in; libmedia lists a TS's streams as their first packets come;
   * - start: where to start, in seconds;
   * - dolbyVision: { profile, level, compat } of a Dolby Vision picture (see dvPlan and softDvPlan);
   * - onEvent(name, detail): 'loaded', 'time', 'playing', 'paused', 'waiting', 'ended', 'error', 'suspended' (the
   *   browser holds the sound until a click or key press, which then starts it: 'playing' again);
   *   'audio' (detail: the count of the audio stream playing) when the one asked for wasn't taken, as a profile 5
   *   picture in the browser's player plays only with a sound that player takes; 'audiohw' (the same detail) when it
   *   wasn't taken because an HDR or bigger than 1080p picture must play there, the page having no hardware decoder
   *   (see pictureNeedsMse); 'dvslow' when a profile 5 picture
   *   decoded here goes back to the browser's decoder, the machine too slow (then 'loaded' again); 'dvwrong' (detail:
   *   why, see softDvMissing; 'render' when its renderer didn't reshape the frames) when a profile 5 picture plays in
   *   the wrong colours from the start; 'audiofailed' (detail: the count of the audio stream still playing) when
   *   `selectAudio` couldn't switch; 'slow' (detail: 'insecure' when the page isn't on HTTPS, which leaves the browser
   *   no hardware decoder) when a picture decoded here can't keep up and frames are skipped, said once.
   */
  class Decoder {
    constructor(container, opts) {
      this.container = container;
      this.opts = opts || {};
      this.player = null;
      this.time = 0;
      // libmedia's clock reads the file's own timestamps; ours counts from the first picture's (seconds)
      this.origin = 0;
      this.duration = 0;
      this.paused = true;
      this.ended = false;
      this.volume = 1;
      this.muted = false;
      this.streams = [];
      this.destroyed = false;
      this.audioWanted = this.opts.audio || 0;
      this.subWanted = this.opts.subtitle === undefined ? -1 : this.opts.subtitle;
      this.subEmbedded = -1;
      // libmedia's subtitle turned off. Unless one inside the file is asked for, it would show the file's default
      // until told otherwise: kept off from the start (see holdSubtitle)
      this.subOff = this.subWanted < 0;
      this.rate = 1;
      // PGS inside the file: whether libmedia hands its packets over, the packets of the one shown, and its drawing
      // (the feed outlives the subtitle being turned off: libmedia has handed it what it read ahead)
      this.pgsOk = false;
      this.pgsFeed = null;
      this.pgsFeedIndex = -1;
      this.pgsOverlay = null;
      this.subTurn = 0;
      this.seekTo = null;
      this.seeking = null;
      decoders.add(this);
    }

    /** The time now, in seconds, from the player's clock. */
    now() {
      try {
        if (this.player) {
          const t = Number(this.player.currentTime) / 1000 - this.origin;
          if (Number.isFinite(t)) return Math.max(0, t);
        }
      } catch (e) { /* not playing yet */ }
      return this.time;
    }

    emit(name, detail) {
      if (this.destroyed) return;
      try {
        if (this.opts.onEvent) this.opts.onEvent(name, detail === undefined ? null : detail);
      } catch (e) {
        console.error(e);
      }
    }

    async open(url) {
      // the reads run in workers, which need the whole address
      url = new URL(url, location.href).href;
      await script(BASE + '/libmedia/avplayer.js');
      const AVPlayer = window.AVPlayer && (window.AVPlayer.default || window.AVPlayer);
      if (!AVPlayer) throw new Error('libmedia did not load');
      if (this.destroyed) return;
      const iso = threads();
      const me = this;
      this.url = url;
      this.subRead = undefined;
      // Safari lets sound start only in a click or key press, and libmedia makes its audio context (one for the page)
      // seconds later, when the file is open: held, the film played silent. The media client starts one in the click
      // that opens the player (`window.__cdSound`), which libmedia takes in place of its own
      const unlocked = window.__cdSound;
      if (unlocked && unlocked.state !== 'closed' && (!AVPlayer.audioContext || AVPlayer.audioContext === unlocked)) {
        AVPlayer.audioContext = unlocked;
        // suspended after the click (and after the last film): started again, which needs no click once Safari has let
        // it play; one never let play stays held, and the click on the picture starts it then (armSound)
        if (unlocked.state === 'suspended') await Promise.race([unlocked.resume().catch(() => {}), new Promise((r) => setTimeout(r, 300))]);
        if (this.destroyed) return;
      }
      this.dv = dvPlan(this.opts.dolbyVision);
      this.softDv = !this.dv && !this.hardDv && await softDvPlan(this.opts.dolbyVision);
      // a sound swapped for one the browser's player takes, and why (see mseWhy): said once loaded
      this.audioSwapped = undefined;
      this.audioSwapWhy = '';
      if (this.destroyed) return;
      // the renderer says whether it reshapes the frames (patch_libmedia.py): heard before the first one is drawn
      this.dvShown = undefined;
      if (this.dvHear) this.dvHear.close();
      this.dvHear = null;
      if (this.softDv && typeof BroadcastChannel === 'function') {
        this.dvHear = new BroadcastChannel('cd-dv');
        this.dvHear.onmessage = (e) => { this.dvShown = !!e.data; };
      }
      const player = new AVPlayer({
        // a Dolby Vision picture the browser's player shows as such goes there (see dvPlan)
        ...(this.dv ? { checkUseMSE: () => true } : {}),
        // pictures stored out of the order they are shown, in a file with no times saying when each is: the
        // browser's player (MSE) shows them by those times, out of order; decoded here they come out in order
        ...(!this.dv && this.opts.unordered ? { checkUseMSE: () => false } : {}),
        container: this.container,
        getWasm: (type, codecId) => wasmFor(type, codecId),
        // a profile 5 picture shown right only when decoded here (see softDvPlan)
        enableHardware: !this.softDv,
        enableWebCodecs: true,
        enableWorker: true,
        enableAudioWorklet: true,
        preLoadTime: 4,
        findBestStream(streams, mediaType) {
          // the audio asked for, counted among the audio streams; else the default one, else the first (never a
          // cover picture)
          const info = me.player.getStreams().filter((s) => s.codecparProxy && s.codecparProxy.codecType === mediaType &&
            !(s.disposition & 0x400));
          let pick = mediaType === 1 ? atOrder(info, me.audioWanted, me.opts.audioPids) : undefined;
          // a subtitle: the one asked for, else the default; one libmedia can take (else its subtitle path isn't
          // made, and no other can be picked later)
          const pool = mediaType === 3 ? info.filter((s) => me.subtitleShown(s.codecparProxy.codecId)) : info;
          const sub = mediaType === 3 ? atOrder(info, me.subWanted, me.opts.subtitlePids) : undefined;
          if (sub && pool.includes(sub)) pick = sub;
          if (mediaType === 0) pick = pictureOf(pool);
          if (!pick) pick = pool.find((s) => s.disposition & 1) || pool[0];
          // the browser's player plays a picture only with a sound it takes: one of the same language when the one
          // asked for isn't, where the picture must go there. A profile 5 picture is right only there (said with
          // `audio`); an HDR or bigger than 1080p one on a page with no hardware decoder (WebCodecs) can't keep up
          // anywhere else (said with `audiohw`)
          if (mediaType === 1 && pick && !mseAudio(pick.codecparProxy.codecId)) {
            const why = me.mseWhy();
            const alt = why && mseAudioFor(info, pick);
            if (alt) {
              pick = alt;
              me.audioWanted = info.indexOf(alt);
              me.audioSwapped = me.audioWanted;
              me.audioSwapWhy = why;
            }
          }
          return pick ? streams.find((s) => s.id === pick.id) : undefined;
        },
      });
      this.player = player;
      // the <video> of the player this one replaces (see reopen): libmedia makes its own for the browser's player
      const kept = this.keptVideo;
      this.keptVideo = null;
      if (kept) {
        const make = player.createVideo;
        player.createVideo = function () {
          if (this.video) return make.apply(this, arguments);
          kept.autoplay = true;
          kept.playsInline = true;
          kept.className = 'avplayer-video';
          kept.style.cssText = 'width: 100%; height: 100%;';
          this.options.container.appendChild(kept);
          this.video = kept;
        };
      }
      this.holdSubtitle(player);
      // AVPlayer decodes only the codecs on its own list: ours too (not through MSE, which takes none of them)
      const listed = player.isCodecIdSupported;
      player.isCodecIdSupported = function (id, type, mse) {
        return (!mse && OWN_DECODERS.includes(id)) || listed.apply(this, arguments);
      };
      player.on('time', (pts) => {
        this.time = Math.max(0, Number(pts) / 1000 - this.origin);
        this.emit('time', this.time);
      });
      player.on('played', () => { this.paused = false; this.ended = false; this.emit('playing'); });
      player.on('playing', () => { this.paused = false; this.emit('playing'); });
      player.on('paused', () => { this.paused = true; this.emit('paused'); });
      player.on('seeking', () => {
        if (this.pgsFeed) this.pgsFeed.clear();
        this.softBase = null;
        this.paceBase = null;
        this.emit('waiting');
      });
      player.on('seeked', () => this.emit('time', this.time));
      player.on('ended', () => { this.ended = true; this.paused = true; this.emit('ended'); });
      player.on('error', (e) => this.emit('error', String((e && e.message) || e)));
      player.on('timeout', () => this.emit('error', 'timeout'));
      player.on('resume', () => this.emit('playing'));
      player.on('firstVideoRendered', () => this.emit('rendered'));
      await player.load(url, {
        ext: this.opts.ext || undefined,
        http: { credentials: 'omit' },
      });
      if (this.destroyed) return;
      this.duration = Number(player.getDuration()) / 1000;
      this.origin = this.originMs() / 1000;
      // its Dolby Vision configuration, which libmedia's MP4 for the browser's player carries (chunk 26)
      const picture = this.dv && pictureOf(player.getStreams());
      if (picture && picture.metadata) {
        picture.metadata.cddv = this.dv.box;
        if (this.dv.tag) picture.metadata.cddvtag = this.dv.tag;
      }
      this.streams = player.getStreams().map((s) => ({
        id: s.id,
        index: s.index,
        type: mediaTypeName(s.codecparProxy ? s.codecparProxy.codecType : -1),
        codecId: s.codecparProxy ? s.codecparProxy.codecId : 0,
        width: s.codecparProxy ? s.codecparProxy.width : 0,
        height: s.codecparProxy ? s.codecparProxy.height : 0,
        language: (s.metadata && (s.metadata.language || s.metadata.LANGUAGE)) || '',
        pid: pidOf(s),
        title: (s.metadata && (s.metadata.title || s.metadata.TITLE)) || '',
      }));
      // an MP4's tracks stored far from the picture are read over a connection of their own (patch_libmedia.py)
      try {
        await player.constructor.DemuxerThread.cdFarUrl(player.taskId, url);
      } catch (e) {
        console.warn('cdFarUrl', e);
      }
      const subs = this.streams.filter((s) => s.type === 'Subtitle');
      if (subs.length) {
        const asked = atOrder(subs, this.subWanted, this.opts.subtitlePids);
        await this.readSubtitle(asked ? asked.index : -1);
        this.pgsOk = await hookSubtitles();
        if (this.destroyed) return;
        if (this.pgsOk) {
          // AVPlayer makes its subtitle path only for the codecs it decodes
          const own = player.isCodecIdSupported;
          player.isCodecIdSupported = function (id) {
            return id === PGS || own.apply(this, arguments);
          };
          // the PGS asked for is read from the start: its feed is there before
          const want = atOrder(subs, this.subWanted, this.opts.subtitlePids);
          if (want && want.codecId === PGS) {
            this.pgsFeed = new PgsFeed();
            this.pgsFeedIndex = want.index;
          }
        }
      }
      const start = Number(this.opts.start || 0);
      await player.play({ audio: true, video: true, subtitle: true });
      if (this.destroyed) return;
      if (start > 1) await player.seek(BigInt(Math.floor((start + this.origin) * 1000)));
      this.paused = false;
      this.emit('loaded', JSON.stringify({
        duration: this.duration,
        threads: iso,
        mse: player.isMSE ? player.isMSE() : false,
        streams: this.streams,
        audio: player.getSelectedAudioStreamId(),
      }));
      if (this.audioSwapped !== undefined) {
        this.emit(this.audioSwapWhy === 'hw' ? 'audiohw' : 'audio', String(this.audioSwapped));
      }
      if (this.soundHeld()) {
        this.emit('suspended');
        this.armSound();
      }
      player.on('audioContextRunning', () => {
        this.disarmSound();
        this.emit('playing');
      });
      if (this.softDv) this.watchSoftDv();
      else if (!(player.isMSE && player.isMSE())) this.watchPace(player);
      const dv = this.opts.dolbyVision;
      if (dv && dv.profile === 5 && !this.dv && !this.hardDv) {
        if (!this.softDv) {
          this.emit('dvwrong', softDvMissing());
        } else if (this.dvHear) {
          // its frames drawn a while and none reshaped: libmedia drew with WebGL, or FFmpeg didn't take the picture for
          // profile 5
          const check = () => {
            if (this.destroyed || this.hardDv || !this.softDv || this.player !== player) return;
            if (this.dvShown === undefined && (this.paused || document.hidden)) {
              this.dvCheck = setTimeout(check, 2000);
              return;
            }
            if (this.dvShown !== true) this.emit('dvwrong', 'render');
          };
          this.dvCheck = setTimeout(check, 6000);
        }
      }
    }

    /**
     * A profile 5 picture decoded here: when the machine can't keep up (under four fifths of the film's frames shown
     * with packets waiting, three checks running; libmedia then skips frames in the decoder), it plays on from where it
     * is with the browser's decoder, its colours wrong (said with `dvslow`). Counted only while the page is in view:
     * libmedia draws no frames in a hidden tab, and takes a moment to catch up when it's back.
     */
    watchSoftDv() {
      clearInterval(this.softWatch);
      this.softBase = null;
      const v = pictureOf(this.player.getStreams());
      const f = v && v.codecparProxy.framerate;
      const fps = f && f.den ? f.num / f.den : 24;
      let slow = 0;
      this.followShown();
      this.softWatch = setInterval(() => {
        const p = this.player;
        if (!p || this.destroyed || !this.softDv) {
          clearInterval(this.softWatch);
          return;
        }
        if (this.paused || this.ended || document.hidden || performance.now() - (this.softShownAt || 0) < 4000) {
          this.softBase = null;
          slow = 0;
          return;
        }
        let shown;
        let queued;
        try {
          const stats = p.getStats();
          shown = Number(stats.videoFrameRenderCount) || 0;
          queued = Number(stats.videoPacketQueueLength) || 0;
        } catch (e) {
          return;
        }
        const at = this.now();
        if (this.softBase && at - this.softBase[1] > 1) {
          // with hardly anything to decode it's the reading that's behind: the browser's decoder wouldn't help
          slow = queued >= fps && (shown - this.softBase[0]) / (at - this.softBase[1]) < fps * 0.8 ? slow + 1 : 0;
          if (slow >= 3) {
            clearInterval(this.softWatch);
            this.hardwareDv();
            return;
          }
        }
        this.softBase = [shown, at];
      }, 2000);
    }

    /** Counts the time since the page came back into view (libmedia draws nothing in a hidden tab, then catches up). */
    followShown() {
      if (this.onSoftVisibility) return;
      this.onSoftVisibility = () => { this.softShownAt = performance.now(); };
      document.addEventListener('visibilitychange', this.onSoftVisibility);
    }

    /**
     * A picture decoded here that the machine can't keep up with, counted as for a profile 5 one (see watchSoftDv):
     * libmedia then skips frames in the decoder, down to keyframes only. Said once with `slow`, detail 'insecure' on a
     * page not on HTTPS, where the browser has no hardware decoder (WebCodecs) and decodes in the page, slowly.
     */
    watchPace(player) {
      clearInterval(this.paceWatch);
      this.paceBase = null;
      if (this.paceTold) return;
      const v = pictureOf(player.getStreams());
      if (!v) return;
      const f = v.codecparProxy.framerate;
      const fps = f && f.den ? f.num / f.den : 24;
      let slow = 0;
      this.followShown();
      this.paceWatch = setInterval(() => {
        if (this.destroyed || this.player !== player) {
          clearInterval(this.paceWatch);
          return;
        }
        if (this.paused || this.ended || document.hidden || performance.now() - (this.softShownAt || 0) < 4000) {
          this.paceBase = null;
          slow = 0;
          return;
        }
        let shown;
        let queued;
        try {
          const stats = player.getStats();
          shown = Number(stats.videoFrameRenderCount) || 0;
          queued = Number(stats.videoPacketQueueLength) || 0;
        } catch (e) {
          return;
        }
        const at = this.now();
        if (this.paceBase && at - this.paceBase[1] > 1) {
          // with hardly anything to decode it's the reading that's behind, not the decoding
          slow = queued >= fps && (shown - this.paceBase[0]) / (at - this.paceBase[1]) < fps * 0.8 ? slow + 1 : 0;
          if (slow >= 3) {
            clearInterval(this.paceWatch);
            this.paceTold = true;
            this.emit('slow', window.isSecureContext ? '' : 'insecure');
            return;
          }
        }
        this.paceBase = [shown, at];
      }, 2000);
    }

    /** The picture from the browser's decoder again, from where it is, with the sound and subtitle playing. */
    async hardwareDv() {
      if (this.destroyed || !this.player) return;
      this.hardDv = true;
      await this.reopen(false, () => this.emit('dvslow'));
    }

    /**
     * libmedia's player made again for the file, playing on from where it was with the sound now asked for
     * (`audioWanted`) and the subtitle shown. `keepVideo`: the new one plays in the old one's <video> (the browser's
     * player, MSE), which Safari has let play sound; a new one it would hold silent until the next click. Called in the
     * click that asks for it, that <video> is told so in it. `stopped` runs once the old one is gone.
     */
    async reopen(keepVideo, stopped) {
      const at = this.now();
      const paused = this.paused;
      const sub = this.subEmbedded;
      const ext = this.extShown ? this.extSub : null;
      const p = this.player;
      const v = keepVideo && p.isMSE && p.isMSE() ? p.video : null;
      // play() in a click is what Safari lets play sound (an element playing already plays on)
      if (v && !v.paused && !v.muted) v.play().catch(() => {});
      this.player = null;
      this.dropPgs();
      try {
        await p.stop(true);
      } catch (e) { /* already stopped */ }
      try {
        await p.destroy();
      } catch (e) { /* gone */ }
      if (this.destroyed) return;
      if (v) {
        // the old player's handlers, until the new one sets its own
        v.ontimeupdate = v.onended = v.onwaiting = v.oncanplay = v.onencrypted = null;
        this.keptVideo = v;
      }
      if (stopped) stopped();
      this.emit('waiting');
      this.opts.start = at;
      // the subtitle shown read from the start (nothing to read again), or none
      this.subWanted = sub;
      this.subOff = sub < 0;
      await this.open(this.url);
      if (this.destroyed || !this.player) return;
      this.player.setVolume(this.muted ? 0 : this.volume);
      if (this.rate !== 1) this.player.setPlaybackRate(this.rate);
      if (ext) await this.addTextSubtitle(...ext);
      else await this.selectSubtitle(sub);
      if (paused) await this.pause();
    }

    /**
     * Where the file's time starts among its timestamps, in ms: the picture's first (the sound's without one); under
     * 1000 ticks counts as 0. A TS starts past 0, a Blu-ray title often at an hour or more.
     */
    originMs() {
      const list = this.player ? this.player.getStreams() : [];
      const type = (s) => (s.codecparProxy ? s.codecparProxy.codecType : -1);
      const s = pictureOf(list) || list.find((x) => type(x) === 1);
      if (!s || typeof s.startTime !== 'bigint' || s.startTime < BigInt(1000) || !s.timeBase || !s.timeBase.den) return 0;
      return Number(s.startTime) * 1000 * s.timeBase.num / s.timeBase.den;
    }

    /** The picture's stream among `streams` (see pictureOf). */
    picture() {
      const p = this.player && pictureOf(this.player.getStreams());
      return this.streams.find((s) => p && s.id === p.id) || this.streams.find((s) => s.type === 'Video');
    }

    /** Where the picture is drawn in the container, for subtitles over it. */
    pictureRect() {
      const r = this.container.getBoundingClientRect();
      const v = this.picture();
      if (!v || !v.width || !v.height || !r.width || !r.height) return { x: 0, y: 0, w: r.width, h: r.height };
      const scale = Math.min(r.width / v.width, r.height / v.height);
      const w = v.width * scale;
      const h = v.height * scale;
      return { x: (r.width - w) / 2, y: (r.height - h) / 2, w, h };
    }

    async play() {
      if (!this.player) return;
      if (this.player.isSuspended && this.player.isSuspended()) {
        // the browser held the sound until a click: playing already, only silent
        await this.player.resume();
        if (!this.paused) return;
      } else if (this.onSoundGesture && !this.paused && !this.ended) {
        // its player's sound let out by this click (armSound): playing already
        return;
      }
      if (this.ended) {
        await this.player.seek(BigInt(Math.floor(this.origin * 1000)));
        this.ended = false;
      }
      await this.player.play();
      this.paused = false;
    }

    async pause() {
      if (!this.player) return;
      await this.player.pause();
      this.paused = true;
    }

    async seek(seconds) {
      if (!this.player) return;
      this.time = Math.max(0, seconds);
      if (this.pgsFeed) this.pgsFeed.clear();
      this.ended = false;
      // libmedia drops a seek asked for during another: the last one asked for goes next, as when skipping on quickly
      this.seekTo = this.time;
      if (this.seeking) return this.seeking;
      this.seeking = (async () => {
        while (this.seekTo !== null && this.player) {
          const to = this.seekTo;
          this.seekTo = null;
          try {
            await this.player.seek(BigInt(Math.floor((to + this.origin) * 1000)));
          } catch (e) {
            console.warn('seek', e);
          }
        }
        this.seeking = null;
      })();
      return this.seeking;
    }

    setVolume(v) {
      this.volume = Math.max(0, Math.min(1, v));
      if (this.player) this.player.setVolume(this.muted ? 0 : this.volume);
    }

    setMuted(m) {
      this.muted = !!m;
      if (this.player) this.player.setVolume(this.muted ? 0 : this.volume);
    }

    setRate(r) {
      this.rate = r;
      if (this.player) this.player.setPlaybackRate(r);
    }

    /**
     * Why the picture must play in the browser's player, which then needs a sound it takes: 'dv' (a profile 5 picture,
     * right only there), 'hw' (HDR or bigger than 1080p with no hardware decoder in the page, see pictureNeedsMse), or
     * '' (it needn't: libmedia decodes it here when the sound isn't one that player takes).
     */
    mseWhy() {
      if (this.dv) return this.dv.tag ? 'dv' : '';
      if (this.opts.unordered || this.softDv || !this.player) return '';
      const v = pictureOf(this.player.getStreams());
      return v && pictureNeedsMse(v.codecparProxy) ? 'hw' : '';
    }

    /** The audio stream at `order` among the file's audio streams. */
    async selectAudio(order) {
      const a = atOrder(this.streams.filter((s) => s.type === 'Audio'), order, this.opts.audioPids);
      // a picture that must play in the browser's player keeps a sound that player takes (said with `audio` or
      // `audiohw`, see mseWhy)
      if (a && this.player && this.player.isMSE && this.player.isMSE() && !mseAudio(a.codecId)) {
        const why = this.mseWhy();
        if (why) {
          this.emit(why === 'hw' ? 'audiohw' : 'audio', String(this.audioWanted));
          return;
        }
      }
      const before = this.audioWanted;
      this.audioWanted = order;
      if (!a || !this.player) return;
      const p = this.player;
      const mse = p.isMSE && p.isMSE();
      // one the browser's player can't be moved to as it plays: the player made again with it
      if (mse && mseSwitchRefused(this.codecparOf(p.getSelectedAudioStreamId()), this.codecparOf(a.id))) {
        await this.reopenForAudio();
        return;
      }
      // libmedia hands the new stream all it kept of it since the file began: its sound started from there, out of
      // step, and in a Blu-ray's TS a TrueHD track's packets (1200 a second) were enough to stop its reader for good.
      // A seek before lets go of them; one after starts the new sound here.
      const playing = !this.ended;
      if (playing) await this.seek(this.now());
      try {
        await this.player.selectAudio(a.id);
      } catch (e) {
        if (mse && this.player === p && /switch stream in mse/.test(String(e && e.message))) {
          await this.reopenForAudio();
          return;
        }
        // not switched: the one still playing (said with `audiofailed`)
        console.warn('selectAudio', e);
        this.audioWanted = before;
        this.emit('audiofailed', String(before));
        return;
      }
      if (playing) await this.seek(this.now());
    }

    /** libmedia's codec parameters (its proxy) of the stream `id`. */
    codecparOf(id) {
      const s = this.player && this.player.getStreams().find((x) => x.id === id);
      return s ? s.codecparProxy : null;
    }

    /** The player made again with the sound asked for (`audioWanted`), in its <video> (see reopen). */
    async reopenForAudio() {
      try {
        await this.reopen(true);
      } catch (e) {
        console.warn('reopen', e);
        this.emit('error', String((e && e.message) || e));
      }
    }

    /** The embedded subtitle at `order` among the file's subtitle streams; -1 for none. */
    async selectSubtitle(order) {
      if (!this.player) return;
      this.extShown = false;
      const turn = ++this.subTurn;
      const s = atOrder(this.streams.filter((x) => x.type === 'Subtitle'), order, this.opts.subtitlePids);
      const pgs = order >= 0 && !!s && s.codecId === PGS;
      this.hidePgs();
      if (order < 0 || !s || (pgs && !this.pgsOk)) {
        this.player.setSubtitleEnable(false);
        this.subOff = true;
        this.subEmbedded = -1;
        await this.readSubtitle(-1);
        if (s && pgs) this.emit('subtitle', 'unshown');
        return;
      }
      // libmedia picks the file's default subtitle itself: selecting it again fails, showing it is enough
      const switching = this.player.getSelectedSubtitleStreamId() !== s.id;
      // its packets come as soon as libmedia switches: the feed is there before (kept when it's the same stream)
      let fresh = false;
      if (!pgs) this.dropPgs();
      else if (switching || !this.pgsFeed || this.pgsFeedIndex !== s.index) {
        this.pgsFeed = new PgsFeed();
        this.pgsFeedIndex = s.index;
        fresh = true;
      }
      // on before libmedia is asked: its switch starts the subtitle, which holdSubtitle stops while off
      const wasOff = this.subOff;
      this.subOff = false;
      if (switching) await this.player.selectSubtitle(s.id);
      if (!this.player || turn !== this.subTurn) return;
      this.player.setSubtitleEnable(true);
      const unread = MP4_READ.includes(this.opts.ext) && this.subRead !== s.index;
      await this.readSubtitle(s.index);
      if (!this.player || turn !== this.subTurn) return;
      // what libmedia read ahead of the picture (seconds of it) went by without this subtitle's lines: a new stream,
      // a stream not being read, a new PGS feed, or text turned off (libmedia drops its lines meanwhile). Read again
      // from here.
      const missed = switching || unread || (pgs ? fresh : wasOff);
      this.subEmbedded = order;
      if (missed && !this.ended) await this.seek(this.now());
      if (!this.player || turn !== this.subTurn) return;
      if (!pgs) return;
      if (this.player.getSelectedSubtitleStreamId() !== s.id) {
        this.dropPgs();
        this.emit('subtitle', 'unshown');
        return;
      }
      const o = new Subtitles({ decoder: this }, { kind: 'pgs', feed: this.pgsFeed });
      this.pgsOverlay = o;
      try {
        await o.open();
      } catch (e) {
        console.warn('PGS', e);
        if (this.pgsOverlay === o) {
          this.dropPgs();
          this.emit('subtitle', 'unshown');
        }
      }
    }

    /**
     * Only the subtitle showing is read from the file (`index`, its stream's; -1: none). An MP4 may keep its subtitles
     * GBs from the picture (DVSUX's: up to 44 tracks), and libmedia's reader goes through every track's samples in
     * turn, whether shown or not: it took all of a seek's first read, and each line of each track after. Its MP4 reader
     * leaves out a stream discarded (48: FFmpeg's AVDISCARD_ALL); no other reader asks. A stream read again starts from
     * the next seek.
     */
    async readSubtitle(index) {
      const p = this.player;
      if (!p || !MP4_READ.includes(this.opts.ext) || this.subRead === index) return;
      this.subRead = index;
      try {
        await Promise.all(this.streams.filter((s) => s.type === 'Subtitle')
          .map((s) => p.constructor.DemuxerThread.setAVStreamDiscard(p.taskId, s.index, s.index === index ? 0 : 48)));
      } catch (e) {
        console.warn('readSubtitle', e);
      }
    }

    /**
     * libmedia starts its subtitle again after each pause, seek and switch, one turned off too (`setSubtitleEnable`
     * only stops it): the file's default text came back over the ASS or PGS the page draws, or over none. Its subtitle
     * starts only while it's on here (`subOff`).
     */
    holdSubtitle(player) {
      const me = this;
      const make = player.createSubtitleRender;
      if (typeof make !== 'function') return;
      player.createSubtitleRender = async function () {
        const out = await make.apply(this, arguments);
        const r = this.subtitleRender;
        if (r && typeof r.start === 'function' && !r.cdHeld) {
          r.cdHeld = true;
          const start = r.start;
          r.start = function () {
            if (me.subOff && me.player === player) return undefined;
            return start.apply(this, arguments);
          };
        }
        return out;
      };
    }

    /** Whether a subtitle stream in `codecId` is drawn here: libmedia's text and ASS, and PGS once hooked. */
    subtitleShown(codecId) {
      return TEXT_SUBS.includes(codecId) || (codecId === PGS && this.pgsOk);
    }

    /** PGS no longer drawn; what was read of it kept, for turning it on again. */
    hidePgs() {
      const o = this.pgsOverlay;
      this.pgsOverlay = null;
      if (o) o.destroy();
    }

    dropPgs() {
      this.hidePgs();
      this.pgsFeed = null;
      this.pgsFeedIndex = -1;
    }

    /** A text subtitle beside the video, as WebVTT text (read and converted by the page), drawn by libmedia. */
    async addTextSubtitle(vtt, lang, title) {
      if (!this.player) return -1;
      const turn = ++this.subTurn;
      // libmedia's subtitle path, mended (without threads it shows nothing else)
      await hookSubtitles();
      const p = this.player;
      if (!p || turn !== this.subTurn) return -1;
      // libmedia's reader takes a cue at the blank line after it: the last one too (else it's lost, a file of one fails)
      const file = new File([vtt.replace(/\s*$/, '\n\n')], 'subtitle.vtt', { type: 'text/vtt' });
      // libmedia 1.3.1 answers 0 whatever stream it adds (selecting 0 failed, and the file's default subtitle showed in
      // place of this one): the stream added is the one it didn't have
      const had = new Set(p.getStreams().map((s) => s.id));
      // on before libmedia is asked: loading may make and start its subtitle (see holdSubtitle)
      this.subOff = false;
      await p.loadExternalSubtitle({ source: file, lang: lang || '', title: title || '' });
      if (this.player !== p || turn !== this.subTurn) return -1;
      const added = p.getStreams().find((s) => !had.has(s.id));
      if (!added) return -1;
      await this.readSubtitle(-1);
      if (this.player !== p || turn !== this.subTurn) return -1;
      // selected first: turned on, it reads the subtitle selected from where the picture is
      if (p.getSelectedSubtitleStreamId() !== added.id) await p.selectSubtitle(added.id);
      if (this.player !== p || turn !== this.subTurn) return -1;
      p.setSubtitleEnable(true);
      // kept for opening the file again (hardwareDv)
      this.extSub = [vtt, lang, title];
      this.extShown = true;
      return added.id;
    }

    hideSubtitles() {
      this.extShown = false;
      this.hidePgs();
      if (this.player) this.player.setSubtitleEnable(false);
      this.subOff = true;
      this.readSubtitle(-1);
    }

    resize() {
      if (!this.player) return;
      const r = this.container.getBoundingClientRect();
      if (r.width && r.height) this.player.resize(r.width, r.height);
    }

    /** Whether the picture can go full screen as a <video> (see videoFullScreen), where the page itself can't. */
    canVideoFullScreen() {
      if (!this.player || typeof HTMLVideoElement !== 'function' || !('webkitEnterFullscreen' in HTMLVideoElement.prototype)) {
        return false;
      }
      if (this.player.isMSE && this.player.isMSE()) return !!this.container.querySelector('video');
      return !!this.container.querySelector('canvas') && typeof HTMLCanvasElement.prototype.captureStream === 'function';
    }

    /**
     * Full screen on an iPhone, whose Safari takes only a <video> there, with the system's controls: the browser's
     * player's own (MSE), else a <video> playing a copy of the picture drawn here, with the ASS and PGS subtitles drawn
     * on it. The text subtitle showing is handed to that <video> as a cue (libmedia draws it in the page, hidden behind).
     * Its Play and Pause play and pause the film. Called in the click: Safari goes full screen nowhere else.
     */
    videoFullScreen() {
      if (this.fullEnd || !this.canVideoFullScreen()) return false;
      const own = this.player.isMSE && this.player.isMSE() ? this.container.querySelector('video') : null;
      const mirror = own ? null : this.mirrorVideo();
      const v = own || (mirror && mirror.video);
      if (!v) return false;
      const stopCues = this.cueFeed(v);
      // the system's Play and Pause (not the copy's own start, nor its pause for a paused film)
      const theirs = () => v.webkitDisplayingFullscreen && (!mirror || mirror.ready);
      const onPause = () => {
        if (mirror) mirror.showInfo();
        if (theirs() && !this.paused && !v.ended) {
          this.pause();
          this.emit('paused');
        }
      };
      const onPlay = () => {
        if (mirror) mirror.showInfo();
        if (theirs() && this.paused) {
          this.play();
          this.emit('playing');
        }
      };
      // the browser's player's own: a jump in the system's bar, where it shows one, is a seek (libmedia, feeding it,
      // doesn't see it); libmedia's own moves come during a seek, or are small
      let at = v.currentTime;
      const onTime = () => {
        if (!v.seeking) at = v.currentTime;
      };
      const onSeeking = () => {
        if (own && theirs() && !this.seeking && Math.abs(v.currentTime - at) > 2) {
          this.seek(Math.max(0, v.currentTime - this.origin));
        }
      };
      const end = () => {
        if (this.fullEnd !== end) return;
        this.fullEnd = null;
        for (const [k, f] of on) v.removeEventListener(k, f);
        stopCues();
        if (mirror) mirror.stop();
        // the phone may have turned meanwhile
        this.resize();
      };
      const on = [['pause', onPause], ['play', onPlay], ['timeupdate', onTime], ['seeking', onSeeking],
        ['webkitendfullscreen', end]];
      this.fullEnd = end;
      for (const [k, f] of on) v.addEventListener(k, f);
      const enter = () => {
        try {
          v.webkitEnterFullscreen();
          return true;
        } catch (e) {
          return false;
        }
      };
      // a copy's <video> may need its first frame first (still inside the click: Safari carries it over a while)
      if (!enter()) {
        if (!mirror) end();
        else mirror.started.then(() => { if (this.fullEnd === end && !enter()) end(); });
      }
      return true;
    }

    /**
     * A <video> over the picture playing a copy of it, drawn here each frame with the ASS and PGS subtitles on it, for
     * full screen (see videoFullScreen): { video, started, ready, stop }. Paused with the film when it is.
     */
    mirrorVideo() {
      const pic = this.container.querySelector('canvas');
      const m = document.createElement('canvas');
      const g = m.getContext('2d');
      if (!pic || !g) return null;
      let last = 0;
      // the time and how far in, drawn on the copy a while after it goes full screen or plays: the system's player has
      // no bar for a stream (it says live). Paused, the copy shows no new frame, so it stays as the pause found it
      let infoAt = performance.now();
      const info = (w, h) => {
        const d = this.duration;
        if (!(d > 0) || (!this.paused && performance.now() - infoAt > INFO_MS)) return;
        const t = Math.min(this.now(), d);
        const u = h / 720;
        const pad = Math.round(32 * u);
        const y = Math.round(h * 0.8);
        const bar = Math.max(2, Math.round(5 * u));
        const shade = g.createLinearGradient(0, y - 70 * u, 0, y + 30 * u);
        shade.addColorStop(0, 'rgba(0,0,0,0)');
        shade.addColorStop(0.5, 'rgba(0,0,0,0.45)');
        shade.addColorStop(1, 'rgba(0,0,0,0)');
        g.fillStyle = shade;
        g.fillRect(0, y - 70 * u, w, 100 * u);
        g.fillStyle = 'rgba(255,255,255,0.35)';
        g.fillRect(pad, y, w - 2 * pad, bar);
        g.fillStyle = '#fff';
        g.fillRect(pad, y, (w - 2 * pad) * (t / d), bar);
        g.font = `600 ${Math.round(24 * u)}px -apple-system, system-ui, sans-serif`;
        g.textBaseline = 'bottom';
        g.textAlign = 'left';
        g.fillText(clockText(t), pad, y - 10 * u);
        g.textAlign = 'right';
        g.fillText('-' + clockText(d - t), w - pad, y - 10 * u);
      };
      const draw = () => {
        const box = this.container.getBoundingClientRect();
        const r = this.pictureRect();
        if (!box.width || !r.w || !r.h) return;
        // paused, still twice a second (the subtitles, a seek)
        const now = performance.now();
        if (this.paused && now - last < 500) return;
        last = now;
        // at most 1280 × 720 (the full screen player scales it up): WebKit turns each frame into the <video>'s on the
        // page's thread, which also feeds the sound decoded here, at a cost that grows with its size (1920 × 1080 took
        // about a third of that thread, and the sound clicked)
        const k = Math.min(window.devicePixelRatio || 1, 1280 / r.w, 720 / r.h);
        const w = Math.round(r.w * k);
        const h = Math.round(r.h * k);
        if (m.width !== w || m.height !== h) {
          m.width = w;
          m.height = h;
        }
        // each canvas by where it lies on the page (the picture's own pixels can lag its box after a turn)
        const put = (c) => {
          const b = c.getBoundingClientRect();
          if (b.width && b.height && c.width && c.height) {
            g.drawImage(c, (b.left - box.left - r.x) * k, (b.top - box.top - r.y) * k, b.width * k, b.height * k);
          }
        };
        put(pic);
        for (const c of this.container.parentElement.querySelectorAll('canvas.mc-sub-canvas')) put(c);
        info(w, h);
      };
      draw();
      let stream;
      try {
        stream = m.captureStream();
      } catch (e) {
        return null;
      }
      // at the film's frame rate (up to 60 a second): twice that took more of the page's thread (see above)
      const sp = pictureOf(this.player.getStreams());
      const fr = sp && sp.codecparProxy && sp.codecparProxy.framerate;
      const fps = fr && fr.den > 0 && fr.num / fr.den > 1 ? fr.num / fr.den : 30;
      const timer = setInterval(draw, 1000 / Math.min(60, fps));
      const v = document.createElement('video');
      v.className = 'mc-dec-copy';
      v.setAttribute('aria-hidden', 'true');
      v.playsInline = true;
      v.muted = true;
      v.autoplay = true;
      // over the picture, unseen: the system's player grows from here and shrinks back to it
      v.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;object-fit:contain;opacity:0;pointer-events:none';
      this.container.appendChild(v);
      v.srcObject = stream;
      const copy = { video: v, ready: false, showInfo: () => { infoAt = performance.now(); last = 0; } };
      copy.started = v.play().catch(() => {}).then(() => {
        if (this.paused) v.pause();
        setTimeout(() => { copy.ready = true; }, 0);
      });
      return Object.assign(copy, {
        stop: () => {
          clearInterval(timer);
          for (const t of stream.getTracks()) t.stop();
          v.srcObject = null;
          v.remove();
        },
      });
    }

    /**
     * libmedia's text subtitle (drawn in the page) handed to `v` as a cue while it shows, as it changes; returns what
     * stops it.
     */
    cueFeed(v) {
      if (typeof VTTCue !== 'function' || !v.addTextTrack) return () => {};
      let track = v.cdCues;
      if (!track) {
        track = v.addTextTrack('subtitles', '', '');
        v.cdCues = track;
      }
      track.mode = 'showing';
      let shown = '';
      let cue = null;
      const clear = () => {
        for (const c of [...(track.cues || [])]) track.removeCue(c);
        cue = null;
      };
      // the cue reaches only just past the time playing, stretched while it shows: the system's bar takes the end of
      // the last cue for the film's length (a cue a day long made the film a day long)
      const feed = () => {
        const lines = [...this.container.querySelectorAll('.ASS-box .ASS-dialogue')]
          .map((d) => (d.innerText || d.textContent || '').replace(/\r/g, '').trim())
          .filter(Boolean);
        const text = lines.join('\n');
        const t = v.currentTime || 0;
        if (text === shown && (!cue || (cue.startTime <= t && t < cue.endTime))) {
          if (cue) cue.endTime = Math.max(cue.endTime, t + 1);
          return;
        }
        shown = text;
        clear();
        if (text) {
          cue = new VTTCue(Math.max(0, t - 0.1), t + 1, text);
          track.addCue(cue);
        }
      };
      feed();
      const timer = setInterval(feed, 100);
      return () => {
        clearInterval(timer);
        clear();
        track.mode = 'disabled';
      };
    }

    /**
     * The sound held by the browser until a click or key press (a page opened from its link, or reloaded; or its own
     * player let play muted, see mutedVideo): the next one anywhere on the page starts it, inside that click (Safari
     * takes it nowhere else).
     */
    armSound() {
      if (this.onSoundGesture) return;
      this.onSoundGesture = () => {
        const p = this.player;
        if (!p || this.destroyed) return this.disarmSound();
        if (p.isSuspended && p.isSuspended()) {
          p.resume().catch(() => {});
        } else if (this.mutedVideo()) {
          // libmedia's resume unmutes its <video> before it first waits: inside this click
          p.resume().catch(() => {});
          // said once the click is through: a Play button reading it at once would take the film for playing and pause it
          setTimeout(() => {
            if (this.player !== p || this.mutedVideo()) return;
            this.disarmSound();
            this.emit('playing');
          }, 0);
        }
      };
      for (const k of SOUND_GESTURES) document.addEventListener(k, this.onSoundGesture, true);
    }

    /**
     * libmedia's <video> (the browser's own player, MSE) when the browser let it play only muted: Safari won't start it
     * with sound outside a click, and the file opens seconds after the click on Play; libmedia then mutes it and plays on,
     * saying nothing (a 4K HDR film with AC-3 played silent). Null when it plays with sound, or has none to play.
     */
    mutedVideo() {
      const p = this.player;
      const v = p && p.isMSE && p.isMSE() && p.video;
      return v && v.muted && p.getSelectedAudioStreamId() >= 0 ? v : null;
    }

    /** Whether the browser holds the sound until a click: its audio context not let start, or its player muted. */
    soundHeld() {
      const p = this.player;
      return !!p && ((p.isSuspended && p.isSuspended()) || !!this.mutedVideo());
    }

    disarmSound() {
      if (!this.onSoundGesture) return;
      for (const k of SOUND_GESTURES) document.removeEventListener(k, this.onSoundGesture, true);
      this.onSoundGesture = null;
    }

    async destroy() {
      this.destroyed = true;
      if (this.fullEnd) this.fullEnd();
      this.disarmSound();
      clearInterval(this.softWatch);
      clearInterval(this.paceWatch);
      clearTimeout(this.dvCheck);
      if (this.dvHear) this.dvHear.close();
      this.dvHear = null;
      if (this.onSoftVisibility) document.removeEventListener('visibilitychange', this.onSoftVisibility);
      this.dropPgs();
      decoders.delete(this);
      const p = this.player;
      this.player = null;
      if (p) {
        // its sound off the speakers at once, not when libmedia's stop gets to it (after its workers answer, a second or
        // more): on an iPad or iPhone the shared context was suspended with a second of the film's sound still in
        // libmedia's node, and it played at the start of the next film, when that started the context again
        try {
          if (p.gainNode) p.gainNode.disconnect();
        } catch (e) { /* not connected */ }
        try {
          await p.stop(true);
        } catch (e) {
          console.warn('stop', e);
        }
        try {
          await p.destroy();
        } catch (e) {
          console.warn('destroy', e);
        }
      }
      // the context started in the click, idle again with no film playing (see open)
      const unlocked = window.__cdSound;
      if (!decoders.size && unlocked && unlocked.state === 'running') unlocked.suspend().catch(() => {});
    }
  }

  // ------------------------------------------------------------------------------ subtitles

  const CJK = /[⺀-鿿가-힯豈-﫿＀-￯]/;

  /**
   * Draws an ASS/SSA or PGS subtitle over a picture. `target`:
   * - { video }: the browser's <video>, followed by the libraries themselves;
   * - { decoder }: a Decoder; a canvas over its picture, its time pushed each frame.
   * `sub`: { kind: 'ass', text }, { kind: 'pgs', url }, or { kind: 'pgs', feed }: a PgsFeed, PGS inside the file the
   * decoder plays.
   */
  class Subtitles {
    constructor(target, sub) {
      this.target = target;
      this.sub = sub;
      this.renderer = null;
      this.canvas = null;
      this.frame = 0;
      this.gone = false;
      this.lastTime = -1;
      this.sentPaused = null;
      this.sentTime = 0;
      this.sentAt = 0;
      // a feed's: a load running, another wanted after it, the one waiting to start
      this.loading = false;
      this.again = false;
      this.reloadTimer = 0;
    }

    async open() {
      const decoder = this.target.decoder;
      if (decoder) {
        const c = document.createElement('canvas');
        c.className = 'mc-sub-canvas';
        c.setAttribute('aria-hidden', 'true');
        c.style.cssText = 'position:absolute;pointer-events:none;z-index:2;left:0;top:0';
        decoder.container.parentElement.appendChild(c);
        this.canvas = c;
        this.place();
      }
      if (this.sub.kind === 'ass') await this.openAss();
      else await this.openPgs();
      if (this.gone) {
        this.destroy();
        return;
      }
      if (decoder) this.tick();
    }

    place() {
      const d = this.target.decoder;
      if (!d || !this.canvas) return;
      const r = d.pictureRect();
      const ratio = window.devicePixelRatio || 1;
      const host = d.container.getBoundingClientRect();
      const parent = d.container.parentElement.getBoundingClientRect();
      const left = Math.round(host.left - parent.left + r.x);
      const top = Math.round(host.top - parent.top + r.y);
      const key = [left, top, Math.round(r.w), Math.round(r.h)].join(',');
      if (key === this.size) return;
      this.size = key;
      // libpgs draws at the subtitle's own size into the (offscreen) canvas; the page only scales it
      Object.assign(this.canvas.style, { left: left + 'px', top: top + 'px', width: r.w + 'px', height: r.h + 'px' });
      if (this.sub.kind === 'pgs') this.lastTime = -1;
      if (this.sub.kind === 'ass' && this.renderer) {
        const v = d.picture();
        // canvas mode: JASSUB takes the picture's size from these
        this.renderer._videoWidth = (v && v.width) || r.w;
        this.renderer._videoHeight = (v && v.height) || r.h;
        this.renderer.resize(Math.round(r.w * ratio), Math.round(r.h * ratio), top, left, true);
      }
    }

    async openAss() {
      await script(BASE + '/jassub/jassub.umd.js');
      const fonts = { 'liberation sans': BASE + '/jassub/default.woff2' };
      const cjk = CJK.test(this.sub.text);
      if (cjk) fonts['noto sans sc'] = BASE + '/fonts/NotoSansSC-subtitle.woff2';
      const options = {
        subContent: this.sub.text,
        workerUrl: BASE + '/jassub/jassub-worker.js',
        wasmUrl: BASE + '/jassub/jassub-worker.wasm',
        modernWasmUrl: BASE + '/jassub/jassub-worker-modern.wasm',
        availableFonts: fonts,
        fallbackFont: cjk ? 'noto sans sc' : 'liberation sans',
        useLocalFonts: false,
      };
      if (this.target.video) options.video = this.target.video;
      else {
        // no <video> to follow: the time is pushed from tick(), and JASSUB predicts the frames between
        options.canvas = this.canvas;
        options.onDemandRender = false;
      }
      this.renderer = new window.JASSUB(options);
      if (this.canvas) {
        this.size = '';
        this.place();
      }
    }

    async openPgs() {
      const mod = await import(BASE + '/libpgs/libpgs.js');
      const options = { workerUrl: BASE + '/libpgs/libpgs.worker.js' };
      if (this.target.video) options.video = this.target.video;
      else options.canvas = this.canvas;
      this.renderer = new mod.PgsRenderer(options);
      const feed = this.sub.feed;
      if (feed) {
        feed.onChange = () => this.reloadSoon();
        await this.reload();
        return;
      }
      const resp = await fetch(this.sub.url, { credentials: 'omit' });
      if (!resp.ok) throw new Error('subtitle ' + resp.status);
      await this.renderer.loadFromBuffer(await resp.arrayBuffer());
    }

    /** More of the feed read (or a seek): loaded again in a moment, the read gathered. */
    reloadSoon() {
      if (this.gone || this.reloadTimer) return;
      this.reloadTimer = setTimeout(() => {
        this.reloadTimer = 0;
        this.reload().catch((e) => console.warn('PGS', e));
      }, 200);
    }

    /** libpgs given the feed's window from the decoder's time on, one load at a time. */
    async reload() {
      if (this.loading) {
        this.again = true;
        return;
      }
      this.loading = true;
      try {
        do {
          this.again = false;
          const bytes = this.sub.feed.buffer(this.target.decoder.now() * 1000);
          if (!this.renderer) return;
          await this.renderer.loadFromBuffer(bytes.buffer);
        } while (this.again && !this.gone);
      } finally {
        this.loading = false;
      }
      // the sets are counted afresh: drawn again even at the index it drew last
      if (this.renderer && this.renderer.implementation) this.renderer.implementation.previousTimestampIndex = -2;
      this.lastTime = -1;
    }

    tick() {
      if (this.gone) return;
      const d = this.target.decoder;
      this.place();
      const t = d.now();
      if (this.renderer) {
        if (this.sub.kind === 'ass') {
          // told when it pauses, plays or jumps, and each second while it plays; between, JASSUB runs its own clock.
          // Its worker takes 5 s without a time as a pause and stops drawing: the frame then showing stayed (an
          // effect that had ended, until the next jump). Its clock runs at 1x whatever the speed (the worker's rate is
          // fixed): told again as it drifts
          const at = performance.now();
          const guess = this.sentPaused ? this.sentTime : this.sentTime + (at - this.sentAt) / 1000;
          if (this.sentPaused !== d.paused || Math.abs(guess - t) > 0.25 || (!d.paused && at - this.sentAt > 1000)) {
            this.sentPaused = d.paused;
            this.sentTime = t;
            this.sentAt = at;
            this.renderer.setCurrentTime(d.paused, t, d.rate);
          }
        } else if (!this.loading && Math.abs(t - this.lastTime) > 0.02) {
          this.lastTime = t;
          this.renderer.renderAtTimestamp(t);
        }
      }
      this.frame = requestAnimationFrame(() => this.tick());
    }

    destroy() {
      this.gone = true;
      cancelAnimationFrame(this.frame);
      clearTimeout(this.reloadTimer);
      if (this.sub.feed && this.sub.feed.onChange) this.sub.feed.onChange = null;
      const r = this.renderer;
      this.renderer = null;
      if (r) {
        try {
          if (r.destroy) r.destroy();
          else if (r.dispose) r.dispose();
        } catch (e) { /* gone */ }
      }
      if (this.canvas) this.canvas.remove();
      this.canvas = null;
    }
  }

  window.CdMedia = { supported, threads, decodes, Decoder, Subtitles, base: BASE };
})();
