﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-lOCs45frNf+D7me6lKLgUhRCdt4VwHCp9H6Ct+YWzfs=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-cPJgWy8SjMaYFeimGkYy23ls+rDZVmoC\/eMoHpqRc+4=",
      "url": "_framework\/dotnet.7.0.12.iceeeme7kz.js"
    },
    {
      "hash": "sha256-O421u5MzVtmNN7GY9RXR9Ib1uPK4hQfPpzOVofr7iNU=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-vwAkMgGGA\/XIQDk2s\/UjKb+fTk9xcKpa9qhvMBqj8hA=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37\/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-kSWWMNMWEkU0l2c9WGd\/H89oQiF+qe+Qvywe5f7rgcU=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-FjVFcMgw2wf7JcC61eCTlB8n85oE+MCx1x6arxKffvY=",
      "url": "_framework\/BencodeNET.dll"
    },
    {
      "hash": "sha256-5V8ovY1srbIIz7lzzMhLd3nNJ9LJ6bHoBOnLJahv8Go=",
      "url": "_framework\/Blazored.LocalStorage.dll"
    },
    {
      "hash": "sha256-Sr30UiM7JErBe8hojY6HAgaOOgfQE5zHijI0uVypmkM=",
      "url": "_framework\/Blazored.Modal.dll"
    },
    {
      "hash": "sha256-dMHq7CrMWeHn5R1pN72TRE\/5YJfstWId26CDK9F0fKc=",
      "url": "_framework\/BlazorPagination.dll"
    },
    {
      "hash": "sha256-PLZlE236lsdGIZAT0VrwtWuW8+\/QXk02bWT86ZnKMz4=",
      "url": "_framework\/CloudDriveWasm.dll"
    },
    {
      "hash": "sha256-TdEZAI0Vuntv2i\/CEC4xyQ12a6IRNnhzp9A1Pqq4WKg=",
      "url": "_framework\/Google.Protobuf.dll"
    },
    {
      "hash": "sha256-g6lTCC51T9iv6m2TyYME2iTakY\/AOpaVBH3obL9jtnU=",
      "url": "_framework\/Grpc.Core.Api.dll"
    },
    {
      "hash": "sha256-TKQwvgTD\/Si8nrlDkxx10uo+LlDeUfG2rd6vcCPnptE=",
      "url": "_framework\/Grpc.Net.Client.dll"
    },
    {
      "hash": "sha256-ItNwlFZ9GisRnh7tEDv59wwyNFlODH6LEcvE2qOlSFY=",
      "url": "_framework\/Grpc.Net.Client.Web.dll"
    },
    {
      "hash": "sha256-RT9E6YbzkLiQKSSqjnRTRYnNeCi48fdPktecoBa3f3Q=",
      "url": "_framework\/Grpc.Net.Common.dll"
    },
    {
      "hash": "sha256-3o2Xz9YmFwMwBo6bekV4k+OPZwpzjhLf5bjHOjHiEzw=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-YLpSdQNH6BvnDtP5WO1Ix0NKXwDzsnqDbRy3o3CA9aI=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Forms.dll"
    },
    {
      "hash": "sha256-dFDu8b7KtEJQRm6xhkXxVCPpPdFVaKbpr3K3Vt6F6oc=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-fHRcV1aH6zkgQDPDavjk2Vj2xZiIc8sLN74bVNm1IV8=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-EcDo\/GQZkQrOT1Xd0jMPE3NwT5lsMq5DNsPxHVidLDQ=",
      "url": "_framework\/Microsoft.Bcl.AsyncInterfaces.dll"
    },
    {
      "hash": "sha256-y5+O+HE1PNgSn0TwPo3hH4YjhuwltS3gYIkrSTD2QOs=",
      "url": "_framework\/Microsoft.Bcl.HashCode.dll"
    },
    {
      "hash": "sha256-jwuU8F7rNVOmV+vsvTYo3KNLtZkkSHB9wtU8kiR5Pqc=",
      "url": "_framework\/Microsoft.EntityFrameworkCore.Abstractions.dll"
    },
    {
      "hash": "sha256-jn\/W0gQUemSfH2Jjn1HqrwruNu1qxVd6nZ9M6nSGvBs=",
      "url": "_framework\/Microsoft.EntityFrameworkCore.dll"
    },
    {
      "hash": "sha256-MAKm1\/l29LzNn+uTDX\/syx4a2rUfhiDIqjtZDkNKUjs=",
      "url": "_framework\/Microsoft.Extensions.Caching.Abstractions.dll"
    },
    {
      "hash": "sha256-HYFgNAjDjPbemdbcK+C34iuaskOuHBwiGN0QzTsiFLc=",
      "url": "_framework\/Microsoft.Extensions.Caching.Memory.dll"
    },
    {
      "hash": "sha256-X\/f4fDl2cuIRXeWHhK\/f2UqQbFioD+RU4a4CEh0zrrQ=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-9PTAXNUj49C5pebEVtTsoRpdXR2henU28twwbTuo3DE=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-Q5AqJneA2TZnzC0IYzBx6j\/tHRhWAeMbpH3BsV7KgWg=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-kxAYIWa4rTM01T04SrOuuZNppQ+W\/iJzCLIs7KxSTKk=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-vfrYKEAFFCox24A0WSVpyXSmb37165rnBqpkyUF\/QwA=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-hXcGBNUG2DeKwpd9d6WfHIFm87Z2rkTWW4nFNoanF4s=",
      "url": "_framework\/Microsoft.Extensions.Localization.Abstractions.dll"
    },
    {
      "hash": "sha256-U+NRdaIDn7fu335wVvTJCokX6dw\/yPHDE9NOdarL1H8=",
      "url": "_framework\/Microsoft.Extensions.Localization.dll"
    },
    {
      "hash": "sha256-XziYyWU765MMEbzjWk3br4shQynO1GyLBHH65ejG+8M=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-Ph4JcBVRl6blMiw7aGCuJ6OrNtzL9k\/obvxIVmqeWNQ=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-wre+hKKXkMGMevyOJFZjGvHYCrTSOFu4So3qzesaeIA=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-sPdkv1wd7P3O4JLiHZIrkTi2eeGHGBkIkMvVy8fOjvM=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-C7rvODTOKbsdXUYkfssaq\/yvCRQnSYqXo7H8A5mgLHE=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-hrrqtgOYJLG2GCHTtuYdpVxhECNov3eN6Sy\/Di9cooQ=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-MRe1r6QQ7yCkYQHylHWIuwA1PIWz4NqOZzLiQm4Bw1c=",
      "url": "_framework\/netstandard.dll"
    },
    {
      "hash": "sha256-OxEWhtMnbvx2MFaPHdB\/vuLJYOZgzZ4CSMbYyPM3SgE=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-rnxn+9SMuR00gUM\/Lw8snMJxfwTNl2jNQK0qSNMUSi4=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-E375JVV0xT0d\/hAzlrqT\/8iK4wMkC6P4eiuA1+Kd4Yg=",
      "url": "_framework\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-9jmB5+09R0KMLqwMonSzlhrdo8SOlpcbG5U7yutAGNU=",
      "url": "_framework\/System.Collections.NonGeneric.dll"
    },
    {
      "hash": "sha256-h8gPEeFR204UElJ9Zy+tax1Gvg7mDnWvMCAPFos3Xpw=",
      "url": "_framework\/System.Collections.Specialized.dll"
    },
    {
      "hash": "sha256-PabegnMR78lSaTnffhLlyo4GSsv7uIQgMp0Z8zZ8HRQ=",
      "url": "_framework\/System.ComponentModel.Annotations.dll"
    },
    {
      "hash": "sha256-rlxn8B8ZL9MmrA8Z6No3be1RqFhVusoQqKJeEae17JE=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-YAIPoX6CCoR26ans9p+qDi9SKUCnGD9FCzXbtQf5Qyo=",
      "url": "_framework\/System.ComponentModel.Primitives.dll"
    },
    {
      "hash": "sha256-uEQW\/Hc0Mkquwg\/MtHxyNy2T1zROyEadRLZzb3D0Qs4=",
      "url": "_framework\/System.ComponentModel.TypeConverter.dll"
    },
    {
      "hash": "sha256-bI8btpPLxjda3C1HbgQgIuHTQ+WxXn1fwyEjc4s\/6L0=",
      "url": "_framework\/System.Console.dll"
    },
    {
      "hash": "sha256-ZVZqH+kKBupWOiVOMt1Nhy+VjrM6QCpvO9Vomgqv+2Q=",
      "url": "_framework\/System.Diagnostics.Debug.dll"
    },
    {
      "hash": "sha256-FCvGFFR9KybZfO2rd+2ssY0OdEdNwEIJUbfRePH76lI=",
      "url": "_framework\/System.Diagnostics.DiagnosticSource.dll"
    },
    {
      "hash": "sha256-Fejv\/gPaOjbjG5px9VVT\/r\/8pjFBoNVu806apMepkmE=",
      "url": "_framework\/System.dll"
    },
    {
      "hash": "sha256-VFUNSr+kolLWvVYiL542S0IbL\/pgr4efmSDnuhdJtuE=",
      "url": "_framework\/System.IO.Compression.dll"
    },
    {
      "hash": "sha256-CPWRlou1jlcDvjFO+Szz3QH3\/IGXpZ7w8Is28Gypou4=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-egGXvZUpbYC3FHiZFEw1MhtEOKyjOKAroe2\/NDEsNtw=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-BpfnmDqm\/yubDOi\/rbURQ+Mz2lP\/aLuXiiT4q51Qnjg=",
      "url": "_framework\/System.Linq.Expressions.dll"
    },
    {
      "hash": "sha256-4UArlofgX8cbwq3a6Ysnb7BTsKz+Nji+MIp2JQ7tOGs=",
      "url": "_framework\/System.Linq.Queryable.dll"
    },
    {
      "hash": "sha256-AL7WXq1mXHCDO\/BbG1cPD5A\/4\/RAjqpEtpWUO+rwbPg=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-9iiND\/Ihdx+6Z89EhfWOB5KSg9OuzA7zmdGKD5kAV1E=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-Z00IG\/6I440Fgg\/rmA8cfiRQxl5Fn18mQZTcoOxkS+Q=",
      "url": "_framework\/System.Net.NameResolution.dll"
    },
    {
      "hash": "sha256-qsDXkdhS+mtGn7OaAPdG9sSJMBTp31NPx8Nw8WgJBP8=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-4k9GFnkCzhZV6n6nqN3iGAivjX1zt5eTD+SpAXnkA6w=",
      "url": "_framework\/System.Net.Sockets.dll"
    },
    {
      "hash": "sha256-4dRlme0Wt9T+sD87FFm\/BXBJBhRMItI9ExkdZcw+Rxc=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-4p4Wv5sVkGHSLmCPmLabLPb7rxdHuz41b46LNjycDq4=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-uenS5KtHKk4O2GJG9QYDfxGNBNuxpzZz2IIBURwhLo0=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-3y1dbXkVZw1Sww2GhABaBmxznsr4xPfLd5VYCAvWrtM=",
      "url": "_framework\/System.Resources.ResourceManager.dll"
    },
    {
      "hash": "sha256-U9rxrBvVe1LclhQIR+PpQ\/gaxZyqMqqv8JY0L0uHyzI=",
      "url": "_framework\/System.Runtime.dll"
    },
    {
      "hash": "sha256-NIZdT\/hG9Khu\/5TWiigIneI72NiAFEYP+s01+m5RiJQ=",
      "url": "_framework\/System.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-ytP9tPv622NlO8a20ClDqfK1GXsrXFywK1rf0qNtIJI=",
      "url": "_framework\/System.Security.Cryptography.Algorithms.dll"
    },
    {
      "hash": "sha256-ffVbjtF2E0gE8PJL15MfH3WxA0ND+6OkxYfMX+F\/BLk=",
      "url": "_framework\/System.Security.Cryptography.dll"
    },
    {
      "hash": "sha256-pB8wZKYQvY384zIQB2Z8+dQzie35nue6GVjwitMTxqY=",
      "url": "_framework\/System.Security.Cryptography.Primitives.dll"
    },
    {
      "hash": "sha256-62jaTSp4h\/t4ygPGRZWHo3B8+dCDb8\/ZGuOG69ImEBM=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-CE4TLsfURtcAOwCauLyLV4Po8JfeOokp3wjcbbwpNpk=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-Geph+i5uFXSNtfiBZfHiyoJerq3uN0vz4LdWMuj\/AAY=",
      "url": "_framework\/System.Text.RegularExpressions.dll"
    },
    {
      "hash": "sha256-9scWOn0u2bpGGz4HqmzrJZm2sxEdpUCTu\/lh1xdw\/kU=",
      "url": "_framework\/System.Threading.dll"
    },
    {
      "hash": "sha256-BtRisoG+xAjP\/6iTWCeJOo9ANgHcj2m4vUKgxCmii2s=",
      "url": "_framework\/System.Threading.Tasks.dll"
    },
    {
      "hash": "sha256-6XXLO\/2+kS8CSiRPZqa9BkHpdvR7uw8YeUniedQJZGU=",
      "url": "_framework\/System.Threading.Tasks.Extensions.dll"
    },
    {
      "hash": "sha256-GgddcAP14G8qzXvfpaGlVocjXwQU6QqBWGyOwxq2iYI=",
      "url": "_framework\/System.Threading.ThreadPool.dll"
    },
    {
      "hash": "sha256-8OGSiztLzjPDu2Asaw6s1MXPblLzfd4OQaPuou3WKOs=",
      "url": "_framework\/System.Transactions.Local.dll"
    },
    {
      "hash": "sha256-w9dYSQeC5rHVEFcPLMgCpOJDIQEVrEOzWizq1ntXNik=",
      "url": "_framework\/System.Web.HttpUtility.dll"
    },
    {
      "hash": "sha256-adNl0wVbp4naOeDrrJ5ouwb3kCcwJIacqt54PzALvDs=",
      "url": "_framework\/zh-CN\/CloudDriveWasm.resources.dll"
    },
    {
      "hash": "sha256-3r3vHkrnS1tS4oCjAn30WLOBafeSjXxQV86Y9c7\/0RU=",
      "url": "CloudDriveWasm.styles.css"
    },
    {
      "hash": "sha256-BzoYU0RNaG3BWjfvRCeSYIkJpSn7x918+5xVluw5Tkk=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-vov5lh0nJsKXUXcsEEmdiuUoOYuUaXx\/cSkuYjQT834=",
      "url": "css\/clouddrive.css"
    },
    {
      "hash": "sha256-HtsXJanqjKTc8vVQjO4YMhiqFoXkfBsjBWcX91T1jr8=",
      "url": "css\/font-awesome\/css\/all.min.css"
    },
    {
      "hash": "sha256-IMSli8nR1p6TXQbxUokjZGpxW+XiGGZWVcrej18bjAA=",
      "url": "css\/font-awesome\/webfonts\/fa-brands-400.ttf"
    },
    {
      "hash": "sha256-dIMyCQxLjiD5XQ\/1nwviD6nIiTWdOzbUuIbXM3YFQgc=",
      "url": "css\/font-awesome\/webfonts\/fa-brands-400.woff2"
    },
    {
      "hash": "sha256-Uo0CLc5nJfiggR\/ZHY5lE0Rcge8zNTpcMjTquTJVGr8=",
      "url": "css\/font-awesome\/webfonts\/fa-regular-400.ttf"
    },
    {
      "hash": "sha256-jn5eobFfYqsU29QXaOj7zSHMhZpOpdqBJFfucUKZ+zU=",
      "url": "css\/font-awesome\/webfonts\/fa-regular-400.woff2"
    },
    {
      "hash": "sha256-Z6ZXY8f4CQPYFgO765BJ\/CvyhQhHm4PtAR\/iTHH6lQo=",
      "url": "css\/font-awesome\/webfonts\/fa-solid-900.ttf"
    },
    {
      "hash": "sha256-cVKmkz7j1pDsKvPQnanXAXI9Fqo0EKbYDyj\/iGbzuIA=",
      "url": "css\/font-awesome\/webfonts\/fa-solid-900.woff2"
    },
    {
      "hash": "sha256-BRWkI\/gozk5qzPkqLqCwPRnTHMhtmvA3MpHh\/U2180g=",
      "url": "css\/font-awesome\/webfonts\/fa-v4compatibility.ttf"
    },
    {
      "hash": "sha256-aUoXw9nWwF+KrGPFRGFVUqSyIOmk3oY9hzQaa8\/BvI0=",
      "url": "css\/font-awesome\/webfonts\/fa-v4compatibility.woff2"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Hb8l6pO6k0G4MSYUBex02eA87w0rPZo6Tr\/9LAQvdc8=",
      "url": "css\/site.css"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-6Y8OmaO6eOZHcnNmrlCpuqdlHZ3ox9GaP8S4ro0pLSE=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-B\/IsuMenTwjYCk3iwBfb7lDueRqR2AL2fuwAh6aZ9H0=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-bT6TZyGPe24VIQl+ggCXr71Vu6W0O7NqMwPTWZXtnyM=",
      "url": "img\/alipay-58x168.png"
    },
    {
      "hash": "sha256-OmSJsyJYmNdpXXX4UwwkR0TeIiktmb1kox2Lf3MOJis=",
      "url": "img\/ali-promo-qrcode.png"
    },
    {
      "hash": "sha256-2bLbQ2v16edVbuqX7INqZoiS+WF0goNLR6o1j6OGAhw=",
      "url": "img\/audio.png"
    },
    {
      "hash": "sha256-lwqpA1Ni8wD6H9cROreHKP8Av+YKmLZvvfUFSaAf7NA=",
      "url": "img\/cloud115.png"
    },
    {
      "hash": "sha256-Vp47sdviEWxOfg60NkKPqaBuxJu8RkTOr59XYgJ1K78=",
      "url": "img\/cloud189.png"
    },
    {
      "hash": "sha256-OT2HOaBn\/gfYu0UBwPX3S76H1+O+qNEH7pkP5lE+kKw=",
      "url": "img\/cloudaliyundrive.png"
    },
    {
      "hash": "sha256-r26AVwzRRVsB3exoeOUaF9enDI5ugT2JmzhN+mOsyCY=",
      "url": "img\/cloudbaidu.png"
    },
    {
      "hash": "sha256-5+BZIm1vG4MSFl\/Lg9P1QqvGHu\/kpJV4PRHTC9VhyV4=",
      "url": "img\/clouddrive-h.png"
    },
    {
      "hash": "sha256-EdM2ThRqF87ddManbXDwszsddKkTZSXgQthtU6zFaRg=",
      "url": "img\/cloudgoogledrive.png"
    },
    {
      "hash": "sha256-YYmYaBVcvVlWLE7+sTbuZg109B21B61ITnsA4UsJCvw=",
      "url": "img\/cloudgoogledrive_256.png"
    },
    {
      "hash": "sha256-j66dGEpFOsJIpsHqs0YdBfsUVC2gnlzQVcrRarrK5bk=",
      "url": "img\/cloudgoogledrive_okd.png"
    },
    {
      "hash": "sha256-jHtf4JG1KNJRwaA2nxsPQsMks+D\/5cVT7dfMTvANWGE=",
      "url": "img\/cloudhecaiyun.png"
    },
    {
      "hash": "sha256-ynL5CapzpkUd6ZoZOiO22C41aj6x\/3vn37aFEBChKaU=",
      "url": "img\/cloudonedrive_new.png"
    },
    {
      "hash": "sha256-jwfrMWl\/VtM5wuy95HRCs95kBS0FfSP937tlCgDF75o=",
      "url": "img\/cloudwocloud.png"
    },
    {
      "hash": "sha256-8uec+eiyKAyxTkS7ru8WZcBO\/xwCRBeSFiKdNrXMJLE=",
      "url": "img\/favicon.ico"
    },
    {
      "hash": "sha256-Oht9zxupxAhKKrjGeoDOvc8vLUPrxkPfCDMCwUxiaKk=",
      "url": "img\/file.png"
    },
    {
      "hash": "sha256-lmMg7NBojwTaPSWZcQwL\/UWx6meR\/\/GlIAFsD7uII+U=",
      "url": "img\/file32.png"
    },
    {
      "hash": "sha256-7HwAVRSjOjJle9N2wKz5fbTdq1XrrYjXL6riAMwHkTA=",
      "url": "img\/folder.png"
    },
    {
      "hash": "sha256-x1zai+wOZwsUQ72UwyKDJvN1C95sYOZ9PCO4CS5iRak=",
      "url": "img\/folder-00.png"
    },
    {
      "hash": "sha256-xWk78qkIlQdp376KmZMNaWLBtTWa0FoDu6ukCVH12P0=",
      "url": "img\/folder-00-32.png"
    },
    {
      "hash": "sha256-FgEVgt7hn7P++3MQBIafOhIkjMgLPbcfS1TVq+XbaQ8=",
      "url": "img\/folder32.png"
    },
    {
      "hash": "sha256-TJxqSEjU3XFNEivbJOYg6klzhiAWUDfoCt9bkWapvSA=",
      "url": "img\/iina.png"
    },
    {
      "hash": "sha256-pJkL19uwgNsypgcWttmAgpFJeHIjFtXfAutXHmalRlc=",
      "url": "img\/infuse.png"
    },
    {
      "hash": "sha256-umf1y7JtHJE1J0dYFfDI1MRRmwkqdUTwFcwCE2AkAnU=",
      "url": "img\/loading.gif"
    },
    {
      "hash": "sha256-+cyrdCODfyoxejv42wF5VZlFGpJEtxaYtmp2VGE62Qs=",
      "url": "img\/mpvplay.png"
    },
    {
      "hash": "sha256-LnduP5M\/5MFXDmcIj7fNotbPTJ\/mVidBeIuyfsZ5UNU=",
      "url": "img\/nplayer.png"
    },
    {
      "hash": "sha256-fCXhMuKybiFMOItLofX9E61+32a+hEvyLzlHxJjaiAo=",
      "url": "img\/photo.png"
    },
    {
      "hash": "sha256-dWfR+uMdsNrC5fS40hwk4q+YNsE0R90xwyXt0vwEtH4=",
      "url": "img\/photo32.png"
    },
    {
      "hash": "sha256-XsTKA5yeqAN\/YDf87HAKNAdGY\/zL91\/qyDQQcW9gaNU=",
      "url": "img\/pikpak.png"
    },
    {
      "hash": "sha256-Eab6H1L7l5DUQ4vLz7YN\/sAcVCbBRt2WID3kJI5c5Zg=",
      "url": "img\/potplayer.png"
    },
    {
      "hash": "sha256-VxzaDLkxLmJPa\/1gDhpLmQ5Tmei2H44842LKgBGP5pw=",
      "url": "img\/video.png"
    },
    {
      "hash": "sha256-QOqxebWp1vtuhfBfIM63YR+thJ+nlSzIkYaruVMtss4=",
      "url": "img\/video32.png"
    },
    {
      "hash": "sha256-R83jlmOcwrsTitXIRX9JmtMDX3e9mDNXQACBZ7TkHeM=",
      "url": "img\/vlc.png"
    },
    {
      "hash": "sha256-f0FwWcTykJF6kq+Y1qTIZLrC2g82PtrGD5kUGOM3ZQE=",
      "url": "img\/webdav.png"
    },
    {
      "hash": "sha256-ErQ8HjZorJa9IVA8iiQBXIs9NO\/A4NbzEzDTjlVyu8c=",
      "url": "index.html"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "js\/clouddrive.js"
    },
    {
      "hash": "sha256-hhkOXovn+\/waq\/Ptu3z3wDZjYcNebzJjMMp0oZFNEvc=",
      "url": "js\/hammer.min.js"
    },
    {
      "hash": "sha256-UENMN4e\/V1APGDuqEXPdeaOBoZag97G+DGWcOVhYaZk=",
      "url": "js\/html5-qrcode.js"
    },
    {
      "hash": "sha256-XSMtlAMe0+Vbo\/xmX8BX8a3TPQWLLlmn68LrJ3cFN94=",
      "url": "js\/myjs.js"
    },
    {
      "hash": "sha256-KoW8MYYQlEnUiICw7niXXl7OV6wfeHl2DZG43FtQWtg=",
      "url": "js\/myphotoswipe.js"
    },
    {
      "hash": "sha256-QlKuNLQZGB3vyS5WyYm5v84JjpwSdHYGQBtxfcrbGzY=",
      "url": "js\/qrcode.js"
    },
    {
      "hash": "sha256-RhHKfxJHXe1kM\/cIU+riLcEl\/qLmaKHt+\/upLTzCer0=",
      "url": "js\/split.min.js"
    },
    {
      "hash": "sha256-MAap2qDbM+MBXc9wjksPXHIHGSdZCj15syKJ+Qc9JbE=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yGxgE2UZtSaTBTg1y1YbmZA0+dBpWxs+vUxsWH8Otlg=",
      "url": "photoswipe\/default-skin\/default-skin.css"
    },
    {
      "hash": "sha256-GgmX8Iv9eo6fEH+SpQNacvAFoZ0BZqVjIIKoLP98SEU=",
      "url": "photoswipe\/default-skin\/default-skin.css.map"
    },
    {
      "hash": "sha256-mIh\/w5EQ1yETyYDl2PSEWnxmrCic+enxYNIEtc4tkys=",
      "url": "photoswipe\/default-skin\/default-skin.png"
    },
    {
      "hash": "sha256-sQn9iBHWJYS7POpG0\/mI0CmpV0wLjjYQmWDyhd62Kws=",
      "url": "photoswipe\/default-skin\/default-skin.svg"
    },
    {
      "hash": "sha256-gNftPz9LUGKPIZd424FJVefSAHwFvohVZ3j5DuKQcVw=",
      "url": "photoswipe\/default-skin\/preloader.gif"
    },
    {
      "hash": "sha256-FQhiXWr9\/O0bAts0Bg7axhsFE\/OEiBqaHYoh7c0MaWU=",
      "url": "photoswipe\/photoswipe.css"
    },
    {
      "hash": "sha256-SGrWcmZiQ6hgRCjHN6Tu+YZPH\/IHY4pXGFNOmKP3BWA=",
      "url": "photoswipe\/photoswipe.css.map"
    },
    {
      "hash": "sha256-HAeC4wGSJkSzyQl4hUClccYPjM4MvgrFi7j\/PaFP4kE=",
      "url": "photoswipe\/photoswipe.js"
    },
    {
      "hash": "sha256-csLEQWl2e5M6lADp3lAOAd31hEdNdVy4URsuk6OLaqY=",
      "url": "photoswipe\/photoswipe.min.js"
    },
    {
      "hash": "sha256-FEMe4fGPe7\/sjSaaW4Tk3Cy3+UM6hQCG\/zMcBqJSJTY=",
      "url": "photoswipe\/photoswipe-ui-default.js"
    },
    {
      "hash": "sha256-31SqlpZuZG1WK\/TE+Vbmo\/zpveXl5RbYYSeUl3gOfxg=",
      "url": "photoswipe\/photoswipe-ui-default.min.js"
    },
    {
      "hash": "sha256-UcVCXWmgp9LvKXOR4Iyu3UCqBbCwM7fNaTwQL78vd88=",
      "url": "sw-registrator.js"
    },
    {
      "hash": "sha256-NRzGRdnlAxAGthP9SY4CJqDqVewUV+0ZXzfRxXher1I=",
      "url": "_content\/Blazored.Modal\/Blazored.Modal.bundle.scp.css"
    },
    {
      "hash": "sha256-JnMrV9FYOYSibA85LvQGGV3uJ7zv2njdJX1GFslt2Aw=",
      "url": "_content\/Blazored.Modal\/BlazoredModal.razor.js"
    }
  ],
  "version": "DlgyxUYM"
};
